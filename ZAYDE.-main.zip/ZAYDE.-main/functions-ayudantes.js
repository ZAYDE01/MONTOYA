/* ============================================================
   ZAYDE — Cloud Functions del portal de vendedores
   - gestionarAyudante: crear / permisos / quitar (acceso de ayudantes)
   - cerrarSesiones:    "Cerrar sesión en todos los dispositivos"

   Van en functions/index.js (o requiérelo desde ahí:
   Object.assign(exports, require('./ayudantes'));).
   El portal las llama con firebase.functions().httpsCallable(...)
   en la región por defecto (us-central1), así que no hay que
   cambiar nada en vendedor.html.

   Si ya tienes una "cerrarSesiones" desplegada, borra la de abajo.
   ============================================================ */
const functions = require('firebase-functions/v1');
const admin = require('firebase-admin');

if (!admin.apps.length) admin.initializeApp();
const db = admin.firestore();

const PERMS = ['ventas', 'stock', 'piezas'];
const MAX_AYUDANTES = 2;

const err = (code, msg) => new functions.https.HttpsError(code, msg);

// Solo un vendedor ACTIVO (no un ayudante) puede administrar ayudantes.
async function requireSeller(context) {
  if (!context.auth) throw err('unauthenticated', 'Inicia sesión de nuevo.');
  const uid = context.auth.uid;
  const snap = await db.collection('sellers').doc(uid).get();
  if (!snap.exists || snap.data().status !== 'activo') {
    throw err('permission-denied', 'Solo un vendedor activo puede administrar ayudantes.');
  }
  return { uid, seller: snap.data() };
}

function cleanPerms(p) {
  if (!Array.isArray(p)) return [];
  return Array.from(new Set(p.filter(x => PERMS.includes(x))));
}

async function ownHelper(ownerUid, helperUid) {
  if (typeof helperUid !== 'string' || !helperUid) throw err('invalid-argument', 'Ayudante no válido.');
  const ref = db.collection('sellerHelpers').doc(helperUid);
  const snap = await ref.get();
  if (!snap.exists || snap.data().ownerId !== ownerUid) {
    throw err('not-found', 'No encontramos a ese ayudante.');
  }
  return ref;
}

exports.gestionarAyudante = functions.https.onCall(async (data, context) => {
  const { uid, seller } = await requireSeller(context);
  const accion = data && data.accion;

  if (accion === 'crear') {
    const nombre = String(data.nombre || '').trim().slice(0, 60);
    const email = String(data.email || '').trim().toLowerCase();
    const perms = cleanPerms(data.perms);
    if (nombre.length < 2 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      throw err('invalid-argument', 'Escribe el nombre y un correo válido.');
    }
    if (!perms.length) throw err('invalid-argument', 'Elige al menos un permiso.');

    const actuales = await db.collection('sellerHelpers').where('ownerId', '==', uid).get();
    if (actuales.size >= MAX_AYUDANTES) {
      throw err('failed-precondition', 'Ya tienes el máximo de ' + MAX_AYUDANTES + ' ayudantes.');
    }

    let user;
    try {
      // Contraseña aleatoria: el ayudante elige la suya con el correo de "restablecer contraseña".
      user = await admin.auth().createUser({
        email,
        displayName: nombre,
        password: require('crypto').randomBytes(24).toString('base64url'),
        emailVerified: false,
      });
    } catch (e) {
      if (e.code === 'auth/email-already-exists') {
        throw err('already-exists', 'Ese correo ya tiene una cuenta. Usa otro correo para tu ayudante.');
      }
      if (e.code === 'auth/invalid-email') throw err('invalid-argument', 'Ese correo no es válido.');
      console.error('[gestionarAyudante:crear]', e);
      throw err('internal', 'No se pudo crear el acceso. Intenta de nuevo.');
    }

    await db.collection('sellerHelpers').doc(user.uid).set({
      ownerId: uid,
      ownerName: seller.name || '',
      name: nombre,
      email,
      perms,
      status: 'activo',
      createdAt: Date.now(),
    });
    return { ok: true, uid: user.uid };
  }

  if (accion === 'permisos') {
    const perms = cleanPerms(data.perms);
    if (!perms.length) throw err('invalid-argument', 'El ayudante necesita al menos un permiso.');
    const ref = await ownHelper(uid, data.uid);
    await ref.update({ perms });
    return { ok: true };
  }

  if (accion === 'quitar') {
    const ref = await ownHelper(uid, data.uid);
    try { await admin.auth().deleteUser(ref.id); }
    catch (e) { if (e.code !== 'auth/user-not-found') throw err('internal', 'No se pudo quitar el acceso.'); }
    await ref.delete();
    return { ok: true };
  }

  throw err('invalid-argument', 'Acción no válida.');
});

// Marca todas las sesiones del vendedor como revocadas e invalida sus tokens.
// El portal, al ver su propia sesión revocada, cierra sesión solo.
exports.cerrarSesiones = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw err('unauthenticated', 'Inicia sesión de nuevo.');
  const uid = context.auth.uid;

  const snap = await db.collection('sellerSessions').where('sellerId', '==', uid).get();
  const batch = db.batch();
  snap.docs.forEach(d => batch.update(d.ref, { revoked: true }));
  await batch.commit();

  await admin.auth().revokeRefreshTokens(uid);
  return { ok: true, sesiones: snap.size };
});
