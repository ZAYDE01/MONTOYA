// /api/stripe-webhook.js
//
// Este es el "seguro de vida" del flujo de pago: Stripe llama a esta URL
// directamente desde SUS servidores (no desde el navegador del cliente)
// en cuanto un cobro se completa de verdad. Así, el pedido se marca como
// "pagado" en Firestore sin importar qué le pase al navegador del
// cliente después de pagar (que se cierre la pestaña, se vaya el
// internet, etc.) — antes, todo dependía de que el navegador del
// cliente terminara su trabajo, y si no lo hacía, el cliente quedaba
// cobrado sin ningún pedido registrado.
//
// CÓMO ACTIVARLO:
// 1) Sube este archivo a /api/stripe-webhook.js
// 2) Agrega "stripe" y "firebase-admin" a tu package.json (ver el archivo
//    que te dieron junto a este) y vuelve a desplegar.
// 3) En Vercel, agrega estas variables de entorno (aparte de las que ya
//    tenías):
//      STRIPE_WEBHOOK_SECRET = whsec_xxxxx  (te lo dio Stripe al crear el
//                               webhook en Dashboard > Developers > Webhooks)
//      FIREBASE_SERVICE_ACCOUNT_B64 = el archivo .json completo de cuenta
//                               de servicio de Firebase, codificado en
//                               Base64 (esto evita los errores de "llave
//                               privada mal pegada" que dan el típico
//                               error "DECODER routines::unsupported").
//      GMAIL_USER / GMAIL_APP_PASSWORD = las mismas que ya configuraste
//                               para send-status-email.js (se reutilizan
//                               aquí como respaldo, por si el correo desde
//                               el navegador del cliente nunca se mandó)
// 4) En Stripe Dashboard > Developers > Webhooks, confirma que los eventos
//    "payment_intent.succeeded" Y "payment_intent.payment_failed" estén
//    marcados para este endpoint. [NUEVO] Agrega también "charge.refunded":
//    así, un reembolso hecho en Stripe marca como devueltas las ventas de
//    vendedor de ese pago y le avisa al vendedor.
//
// IMPORTANTE: este archivo necesita el cuerpo (body) de la petición SIN
// procesar, para poder verificar la firma de Stripe — por eso existe el
// "export const config" de abajo, que le dice a Vercel que no lo
// convierta a JSON automáticamente como hace con los demás endpoints.

import Stripe from 'stripe';
import admin from 'firebase-admin';
import nodemailer from 'nodemailer';
import crypto from 'crypto';
import { notifySellerLowStock } from './_lib/sellerLowStock.js';
import { layout, pieceRow, pill, table, note, COLORS, applyStripeRefund } from './_lib/sellerEvents.js';
import { orderEmailHtml, simpleEmailHtml, stripEmoji, codeBox, lightNote, SITE_URL as SITE_URL_EMAIL, prepareOrderEmail, canReceiveEmail, emailImagesPlugin } from './_lib/zaydeEmail.js';

export const config = {
  api: { bodyParser: false }
};

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '');

// Normaliza FIREBASE_PRIVATE_KEY sin importar cómo se haya pegado en Vercel
// (respaldo, por si no se configuró FIREBASE_SERVICE_ACCOUNT_B64):
function normalizeFirebasePrivateKey(raw){
  if(!raw) return raw;
  let key = raw.trim();
  if((key.startsWith('"') && key.endsWith('"')) || (key.startsWith("'") && key.endsWith("'"))){
    key = key.slice(1, -1);
  }
  if(key.includes('\\n')) key = key.replace(/\\n/g, '\n');
  return key;
}

// MÉTODO PRINCIPAL: el archivo .json de cuenta de servicio completo,
// codificado en Base64 en una sola variable de entorno
// (FIREBASE_SERVICE_ACCOUNT_B64). Como nunca se pega/edita la llave a
// mano, es inmune a errores de copiado que rompen el formato PEM (el
// error "DECODER routines::unsupported" que daba antes).
function getServiceAccountCredentials(){
  const b64 = process.env.FIREBASE_SERVICE_ACCOUNT_B64;
  if(b64){
    const json = JSON.parse(Buffer.from(b64, 'base64').toString('utf-8'));
    return {
      projectId: json.project_id,
      clientEmail: json.client_email,
      privateKey: json.private_key
    };
  }
  // Respaldo: las 3 variables sueltas (método anterior)
  return {
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: normalizeFirebasePrivateKey(process.env.FIREBASE_PRIVATE_KEY)
  };
}

function getFirestore(){
  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.cert(getServiceAccountCredentials())
    });
  }
  return admin.firestore();
}

async function readRawBody(readable){
  const chunks = [];
  for await (const chunk of readable) {
    chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : chunk);
  }
  return Buffer.concat(chunks);
}

let cachedTransporter = null;
function getMailer(){
  if(cachedTransporter) return cachedTransporter;
  if(!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) return null;
  cachedTransporter = nodemailer.createTransport({
    service: 'gmail',
    auth: { user: process.env.GMAIL_USER, pass: process.env.GMAIL_APP_PASSWORD }
  });
  cachedTransporter.use('compile', emailImagesPlugin); // adjunta el logo y los íconos incrustados
  return cachedTransporter;
}

// [FIX — "me llega una cotización de pedido al comprar una membresía"]
// Este correo de respaldo tenía el texto de "¡Pedido confirmado y
// pagado!" fijo en el código, sin importar qué se hubiera comprado — así
// que una membresía de ZAYDE Club (que no es un "pedido" con envío, se
// activa sola) también recibía ese mismo aviso pensado para piezas
// físicas. El frontend (zySendOrderConfirmationEmail, en index.html) ya
// distingue esto desde antes; aquí se aplica exactamente el mismo
// criterio, para que el correo de respaldo del webhook diga lo mismo que
// el correo normal sin importar cuál de los dos termine llegando primero.
function isDigitalOnlyOrder(order){
  const items = order.items || [];
  return items.length > 0 && items.every(it => it.isMembership || it.isGiftCard);
}
function buildConfirmationHeadline(order){
  const items = order.items || [];
  const membershipItem = items.find(it => it.isMembership);
  const giftItem = items.find(it => it.isGiftCard);
  if(isDigitalOnlyOrder(order)){
    if(membershipItem && giftItem) return '¡Tu membresía y tu tarjeta de regalo ZAYDE ya están activas!';
    if(membershipItem) return `¡Bienvenido a ZAYDE Club! Tu membresía ${membershipItem.tierName || ''} ya está activa.`;
    return '¡Tu tarjeta de regalo ZAYDE ya está activa y lista para usarse!';
  }
  return '¡Pedido confirmado y pagado! ✅';
}

// Correo de respaldo — solo se manda si, por lo que sea, el navegador del
// cliente nunca alcanzó a mandar el suyo (ver checkeo de idempotencia abajo).

// [CORREO DUPLICADO] El correo de confirmación de un pedido lo podían mandar DOS
// caminos: el navegador del cliente (type "status") y el webhook de Stripe (respaldo).
// El respaldo estaba pensado para mandarse SOLO si el navegador no alcanzaba, pero como
// las reglas de Firestore no dejan al navegador marcar el pedido como "pagado", el
// webhook siempre creía que faltaba y mandaba el suyo: llegaban dos iguales.
// Ahora los dos caminos "reclaman" el envío con un documento atómico (emailClaims/
// confirm_<pedido>): el primero que llega lo manda y el otro se salta el suyo. Si el
// envío falla, se suelta el reclamo para que el otro camino pueda intentarlo.
// (La colección emailClaims solo la usa el servidor: queda cerrada por la regla final.)
async function claimConfirmationEmail(db, orderNum) {
  try {
    await db.collection('emailClaims').doc(`confirm_${orderNum}`).create({ at: Date.now() });
    return true;
  } catch (e) {
    if (e && (e.code === 6 || /ALREADY_EXISTS/i.test(String(e.message)))) return false;
    throw e;
  }
}
async function releaseConfirmationEmail(db, orderNum) {
  try { await db.collection('emailClaims').doc(`confirm_${orderNum}`).delete(); } catch (e) { /* no pasa nada */ }
}

async function sendBackupConfirmationEmail(order){
  const mailer = getMailer();
  if(!mailer || !order.email) return;
  // Igual que el correo del navegador (zySendOrderConfirmationEmail): si el cliente
  // pidió no recibir avisos por correo, no se le manda nada.
  if(order.notifyEmail === false) return;
  const db = getFirestore();
  // [CORREO DUPLICADO] Si el navegador ya mandó (o está mandando) la confirmación, este respaldo se salta.
  let claimed = false;
  try{ claimed = await claimConfirmationEmail(db, String(order.orderNum)); }
  catch(e){ console.error('Webhook: no se pudo reclamar el envío de confirmación, se envía de todos modos:', e); claimed = null; }
  if(claimed === false) return;
  // [REBOTES] correo mal escrito o sin servidor de correo: no se envía (evita "Mail Delivery Subsystem")
  if(!(await canReceiveEmail(order.email))){ console.warn('Webhook: correo no válido, se omite la confirmación:', order.email); return; }
  const greetingName = order.name ? escHtml(String(order.name).split(' ')[0]) : 'Hola';
  const headline = buildConfirmationHeadline(order);
  const safeHeadline = escHtml(headline);
  const safeOrderNum = escHtml(order.orderNum);
  const digitalOnly = isDigitalOnlyOrder(order);
  const html = orderEmailHtml(await prepareOrderEmail(db, order), {
    title: digitalOnly ? stripEmoji(headline) : 'Gracias por tu pedido.',
    intro: digitalOnly
      ? greetingName + ', puedes ver el detalle de tu compra en cualquier momento desde tu cuenta en ZAYDE.'
      : greetingName + ', ya confirmamos tu pago. Te enviaremos un número de rastreo en cuanto tu pedido salga.',
    preheader: stripEmoji(headline)
  });
  try{
    await mailer.sendMail({
      from: `"ZAYDE" <${process.env.GMAIL_USER}>`,
      to: order.email,
      subject: `Tu pedido ${order.orderNum} — ${stripEmoji(headline)}`,
      html
    });
  }catch(e){
    console.error('Webhook: no se pudo mandar el correo de respaldo:', e);
    if(claimed) await releaseConfirmationEmail(db, String(order.orderNum)); // suelta el reclamo para que otro camino pueda intentarlo
  }
}

// [NUEVO] Correo cuando el pago SÍ falla (tarjeta rechazada, fondos
// insuficientes, bloqueo antifraude, etc.) — a diferencia del de
// confirmación, este es el ÚNICO aviso que recibe el cliente en este caso,
// porque el navegador nunca llega a mostrar una pantalla de "éxito" que
// pueda mandar su propio correo: si el pago falla, el navegador se queda
// en la pantalla de checkout, y si el cliente simplemente cierra la
// pestaña ahí, antes no se enteraba nadie ni el cliente tenía claro qué
// pasó con su pedido "pendiente".
async function sendPaymentFailedEmail(order, reason){
  const mailer = getMailer();
  if(!mailer || !order.email) return;
  const greetingName = order.name ? escHtml(String(order.name).split(' ')[0]) : 'Hola';
  const whatsappNumber = escHtml(process.env.ZAYDE_WHATSAPP_NUMBER || '');
  const safeOrderNum = escHtml(order.orderNum);
  const safeReason = escHtml(reason || '');
  const html = simpleEmailHtml({
    title: 'No pudimos procesar tu pago.',
    intro: greetingName + ', tu pago para el pedido <b>' + safeOrderNum + '</b> no se pudo procesar.' + (safeReason ? ' Motivo: ' + safeReason + '.' : ''),
    bodyHtml: lightNote('Esto suele pasar por fondos insuficientes, un bloqueo antifraude del banco o un dato de la tarjeta capturado mal. No se te cobró nada y tu pedido sigue reservado como "pendiente".')
      + '<p>Puedes intentar de nuevo desde el sitio, o escribirnos por WhatsApp' + (whatsappNumber ? ' al ' + whatsappNumber : '') + ' y te ayudamos a completar la compra por transferencia.</p>',
    cta: 'Intentar de nuevo', ctaUrl: SITE_URL_EMAIL + '/carrito', orderNum: order.orderNum
  });
  try{
    await mailer.sendMail({
      from: `"ZAYDE" <${process.env.GMAIL_USER}>`,
      to: order.email,
      subject: `Tu pedido ${order.orderNum} — no pudimos procesar el pago`,
      html
    });
  }catch(e){ console.error('Webhook: no se pudo mandar el correo de pago fallido:', e); }
}

// Mensaje humano a partir del código de rechazo de Stripe, para que el
// correo/panel admin digan algo más útil que un código en inglés.
function humanDeclineReason(paymentIntent){
  const err = paymentIntent.last_payment_error;
  if(!err) return '';
  const code = err.decline_code || err.code || '';
  const map = {
    insufficient_funds: 'fondos insuficientes',
    card_declined: 'tarjeta rechazada por el banco',
    expired_card: 'tarjeta vencida',
    incorrect_cvc: 'CVC incorrecto',
    processing_error: 'error al procesar con el banco',
    fraudulent: 'bloqueada por prevención de fraude'
  };
  return map[code] || (err.message ? err.message : '');
}


// ============================================================
// [VENDEDORES] Ventas por vendedor (consignación)
//
// Cuando un pago se confirma de verdad (payment_intent.succeeded), por cada
// pieza del pedido que tenga sellerId se crea UNA fila en "sellerSales".
// Como esto corre en el servidor (SDK de Admin), nadie puede fabricar
// ventas falsas desde el navegador: solo existen ventas realmente pagadas.
//
// PRIVACIDAD: la fila de sellerSales NO lleva nombre, teléfono, dirección,
// correo ni el número de pedido (porque tus reglas dejan leer un pedido
// suelto, "get", a quien conozca su número: si el vendedor viera el folio,
// podría abrir el pedido completo del comprador). El ID de la fila es un
// código opaco (HMAC), y el vínculo con el pedido real vive aparte, en
// "sellerSalesPrivate", que solo lee el admin.
// ============================================================
const RESALE_DEFAULTS = {
  zayde: { 'Ropa':20, 'Sneakers':20, 'Joyería':25, 'Lentes de sol':22.8, 'Bolsos':23.3, 'Gorras':22 },
  zayg:  { 'Ropa':20, 'Joyería':25, 'Lentes de sol':23, 'Bolsos':24, 'Gorras':25 }
};

// Tabla de comisiones que guardas en la pestaña "Reventa" del panel admin
// (vive en admin_meta, junto con el resto de la configuración del sitio).
async function getResaleFees(db){
  let saved = {};
  try{
    const doc = await db.collection('admin_meta').doc(encodeURIComponent('zayde:admin:homeSettings')).get();
    if(doc.exists){
      const value = doc.data().value || {};
      saved = (value.resale && value.resale.fees) || {};
    }
  }catch(e){ console.error('Webhook: no se pudo leer la tabla de Reventa, se usan los porcentajes por defecto:', e); }
  return {
    zayde: Object.assign({}, RESALE_DEFAULTS.zayde, saved.zayde),
    zayg:  Object.assign({}, RESALE_DEFAULTS.zayg,  saved.zayg)
  };
}

// ID opaco y estable (misma pieza del mismo pedido = mismo ID, así un
// reintento de Stripe nunca duplica la venta) pero imposible de adivinar
// o de convertir de vuelta al número de pedido sin la llave secreta.
//
// [FIX #4] Antes la llave del HMAC era STRIPE_WEBHOOK_SECRET: si algún día
// rotabas ese secreto, los IDs cambiaban y un reintento de Stripe duplicaba
// ventas ya registradas. Ahora se usa SALE_ID_SECRET (variable propia, que
// NUNCA debes cambiar una vez en uso). Para no alterar los IDs de ventas ya
// creadas, si SALE_ID_SECRET no existe se usa el secreto anterior como
// respaldo. MIGRACIÓN: crea SALE_ID_SECRET en Vercel con el MISMO valor que hoy
// tiene STRIPE_WEBHOOK_SECRET; a partir de ahí ya puedes rotar el webhook.
function saleIdFor(orderNum, itemIndex){
  const key = process.env.SALE_ID_SECRET || process.env.STRIPE_WEBHOOK_SECRET;
  return crypto.createHmac('sha256', key)
    .update(`${orderNum}:${itemIndex}`).digest('hex').slice(0, 24);
}

const round2 = n => Math.round(n * 100) / 100;

// [% DE ENVÍO INCLUIDO · FONDO DE ZAYDE] El precio de lista de una pieza trae sumado el % de envío de su sección (panel privado >
// Agregar producto). Ese % es el fondo con el que ZAYDE paga los envíos gratis: NO es del vendedor. Por eso la comisión del
// vendedor se calcula sobre el PRECIO BASE (el que él puso), no sobre el precio de lista. Así, sin importar el tamaño del pedido:
//   vendedor = (100% − comisión) del precio base · ZAYDE = su comisión del precio base + el % de envío (el fondo del envío).
// El precio base vive en la colección privada productCosts (solo admin/servidor). Si la pieza no tiene % guardado → ratio 1.
async function sellerBaseRatio(db, it, cache){
  const id = String(it.id);
  if(!(id in cache)){
    cache[id] = { cost: null, list: null };
    try{
      const [cd, pd, od] = await Promise.all([
        db.collection('productCosts').doc(id).get(),
        db.collection('admin_products').doc(id).get(),
        db.collection('admin_overrides').doc(id).get()
      ]);
      cache[id].cost = cd.exists ? cd.data() : null;
      if(pd.exists) cache[id].list = Object.assign({}, pd.data(), od.exists ? od.data() : {});
    }catch(e){ console.error('Webhook: no se pudo leer el costo/precio de la pieza', id, e); }
  }
  const { cost: c, list: prod } = cache[id];
  if(!c || !(Number(c.markupPct) > 0) || !(Number(c.basePrice) > 0)) return 1;
  const bySize = it.size && c.sizeBase ? Number(c.sizeBase[it.size]) : 0;
  const base = bySize > 0 ? bySize : Number(c.basePrice);
  // Precio de lista de ESA pieza/talla: el que está publicado (exacto). Si no se puede leer, se recalcula igual que el panel (zyListPrice).
  const sp = prod && prod.sizePrices;
  let list = prod ? ((sp && it.size && Number(sp[it.size]) > 0) ? Number(sp[it.size]) : Number(prod.price)) : 0;
  if(!(list > 0)) list = Math.ceil(base * (1 + Number(c.markupPct) / 100) / 10 - 1e-9) * 10;
  return list > 0 ? Math.min(1, base / list) : 1;
}

async function createSellerSales(db, orderNum, order, paymentIntent){
  const items = order.items || [];
  const sellerItems = items
    .map((it, index) => ({ it, index }))
    .filter(({ it }) => it && it.sellerId && !it.isMembership && !it.isGiftCard);
  if(!sellerItems.length) return 0;

  const fees = await getResaleFees(db);
  const sellerCache = {};
  const costCache = {};
  let created = 0;
  const toNotify = []; // ventas nuevas (o con aviso pendiente) para mandarle correo al vendedor

  for(const { it, index } of sellerItems){
    const saleId = saleIdFor(orderNum, index);

    if(!(it.sellerId in sellerCache)){
      const sdoc = await db.collection('sellers').doc(String(it.sellerId)).get();
      sellerCache[it.sellerId] = sdoc.exists ? sdoc.data() : null;
    }
    const seller = sellerCache[it.sellerId];

    // Tienda y categoría: vienen en el item (index.html las copia al comprar).
    // Si es un pedido anterior a este cambio, se buscan en el producto.
    let store = it.store, category = it.category;
    if(!category){
      try{
        const pdoc = await db.collection('admin_products').doc(String(it.id)).get();
        if(pdoc.exists){ category = pdoc.data().category || null; store = store || pdoc.data().store || null; }
      }catch(e){ /* sigue sin categoría: la venta queda marcada para revisión */ }
    }
    const line = store === 'clothesg' ? 'zayg' : 'zayde';

    // Comisión: primero la propia del vendedor; si no tiene, la tabla de Reventa.
    let pct = null;
    if(seller && seller.commissionPct != null && isFinite(Number(seller.commissionPct))){
      pct = Number(seller.commissionPct);
    } else if(category && fees[line] && fees[line][category] != null){
      pct = Number(fees[line][category]);
    }

    const qty = Number(it.qty) || 1;
    const listUnit = Number(it.price) || 0;                                        // lo que pagó el cliente (con el % de envío)
    const ratio = await sellerBaseRatio(db, it, costCache);
    const unitPrice = round2(listUnit * ratio);                                    // precio base: lo que el vendedor puso
    const gross = round2(unitPrice * qty);
    const listGross = round2(listUnit * qty);
    const commission = pct == null ? null : round2(gross * pct / 100);
    const net = commission == null ? null : round2(gross - commission);

    const now = Date.now();
    const sale = {
      sellerId: String(it.sellerId),
      productId: it.id != null ? String(it.id) : null,
      productName: it.name || '',
      brand: it.brand || null,
      size: it.size || null,
      qty,
      unitPrice,
      gross,
      commissionPct: pct,
      commission,
      net,
      needsReview: pct == null,      // sin comisión definida: revísala y complétala en el panel
      status: 'pagado',              // pagado → en verificación → enviado → entregado / devuelto
      settled: false,                // true cuando ya le liquidaste esta venta
      createdAt: now,
      paidAt: now
    };

    // [FIX #1] La venta y su vínculo privado con el pedido se escriben en UN
    // SOLO batch (todo o nada). Antes eran dos escrituras separadas: si la
    // segunda fallaba, el reintento de Stripe veía la venta ya creada
    // (ALREADY_EXISTS), la saltaba, y la venta quedaba sin vínculo en
    // sellerSalesPrivate — así applyStripeRefund nunca la encontraba al
    // reembolsar. Ahora, además, en el reintento se REPARA el vínculo si falta.
    const saleRef = db.collection('sellerSales').doc(saleId);
    const privRef = db.collection('sellerSalesPrivate').doc(saleId);
    const privData = { orderNum, itemIndex: index, stripePaymentIntentId: paymentIntent.id, listGross, shipFund: round2(listGross - gross) };   // privado: el vendedor no ve el % de envío
    try{
      const batch = db.batch();
      batch.create(saleRef, sale);
      batch.set(privRef, privData, { merge: true });
      await batch.commit();
      created++;
      toNotify.push({ saleId, sale });
    }catch(e){
      // ALREADY_EXISTS (código 6): Stripe reenvió el evento y esta pieza ya
      // estaba registrada. No se duplica; el batch es atómico, así que aquí
      // NO se escribió nada: se asegura el vínculo privado (por si la venta
      // se creó con la versión anterior del código y le faltaba) y, si el
      // correo al vendedor nunca salió (notifiedAt vacío), se reintenta.
      if(e && (e.code === 6 || /ALREADY_EXISTS/i.test(String(e.message)))){
        await privRef.set(privData, { merge: true }); // si falla, lanza → Stripe reintenta
        try{
          const prev = await saleRef.get();
          if(prev.exists && !prev.data().notifiedAt) toNotify.push({ saleId, sale: prev.data() });
        }catch(err){ console.error('Webhook: no se pudo revisar el aviso pendiente de una venta:', err); }
        continue;
      }
      throw e;
    }
  }

  // Un correo por vendedor con sus piezas de este pedido. Si el correo falla
  // NO se rompe el webhook: la venta ya quedó registrada y el vendedor la ve
  // en su portal; el aviso se reintenta si Stripe vuelve a mandar el evento.
  try{ await notifySellers(db, toNotify, sellerCache); }
  catch(e){ console.error('Webhook: error avisando a los vendedores:', e); }

  return created;
}

// ------------------------------------------------------------
// Correo al vendedor cuando se vende una pieza suya.
// PRIVACIDAD: solo lleva datos de la pieza y lo que le toca. Nunca nombre,
// teléfono, dirección, correo ni número de pedido del comprador.
// ------------------------------------------------------------
const escHtml = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
));
const moneyMx = (n) => '$' + Number(n || 0).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

async function notifySellers(db, toNotify, sellerCache){
  if(!toNotify.length) return;
  const mailer = getMailer();
  if(!mailer){ console.error('Webhook: sin GMAIL_USER / GMAIL_APP_PASSWORD, no se avisa a los vendedores.'); return; }

  const bySeller = {};
  toNotify.forEach(n => { (bySeller[n.sale.sellerId] = bySeller[n.sale.sellerId] || []).push(n); });

  for(const sellerId of Object.keys(bySeller)){
    const seller = sellerCache[sellerId];
    if(!seller || !seller.email || seller.status === 'pausado') continue;
    const list = bySeller[sellerId];
    const greetingName = seller.name ? String(seller.name).split(' ')[0] : 'Hola';
    const pending = list.some(n => n.sale.net == null);
    const total = list.reduce((t, n) => t + (Number(n.sale.net) || 0), 0);

    const rows = list.map(({ sale }) => pieceRow({
      title: (sale.brand ? sale.brand + ' ' : '') + (sale.productName || 'Pieza'),
      sub: (sale.size ? 'Talla ' + escHtml(sale.size) + ' · ' : '') + 'Cantidad ' + escHtml(sale.qty || 1) + ' · Venta ' + moneyMx(sale.gross),
      right: sale.net == null ? pill('Comisión por definir', COLORS.warnBg, COLORS.warnFg) : '<b>' + moneyMx(sale.net) + '</b>'
    }));

    const subject = list.length === 1
      ? `¡Vendiste una pieza en ZAYDE! ${list[0].sale.productName || ''}`.trim()
      : `¡Vendiste ${list.length} piezas en ZAYDE!`;

    const html = layout({
      preheader: subject,
      title: list.length === 1 ? '¡Se vendió una pieza tuya!' : `¡Se vendieron ${list.length} piezas tuyas!`,
      intro: `${escHtml(greetingName)}, se confirmó el pago de ${list.length === 1 ? 'esta pieza' : 'estas piezas'}:`,
      body: table(rows) +
        (total > 0 ? note(`Te tocan <b>${moneyMx(total)}</b>${pending ? ' (más lo de las piezas con comisión por definir)' : ''}.`) : (pending ? note('Te confirmaremos lo que te toca en cuanto definamos la comisión.') : '')) +
        note('Verificaremos la pieza y la enviaremos. Te avisaremos por correo cada vez que avance, y puedes ver el estado de tus ventas y tu stock en tu portal.'),
      cta: 'Abrir mi portal de vendedor'
    });

    try{
      await mailer.sendMail({ from: `"ZAYDE" <${process.env.GMAIL_USER}>`, to: seller.email, subject, html });
      const batch = db.batch();
      list.forEach(n => batch.update(db.collection('sellerSales').doc(n.saleId), { notifiedAt: Date.now() }));
      await batch.commit();
    }catch(e){
      console.error('Webhook: no se pudo avisar por correo a un vendedor:', e);
    }
  }
}

// [AVISO AL DUEÑO · MONTO NO COINCIDE] Cuando un cobro no cuadra con el total del pedido,
// el pedido NO se marca pagado y antes solo quedaba la bandera "amountMismatch" en Firestore
// (nadie se enteraba). Ahora se manda un correo al dueño al instante, por el mismo Gmail del
// webhook (sin archivos /api nuevos). Destino: OWNER_EMAIL si existe en Vercel; si no, GMAIL_USER.
// Nunca debe romper el webhook: cualquier fallo solo se registra en consola.
async function notifyOwnerAmountMismatch(order, orderNum, info){
  try{
    const mailer = getMailer();
    const to = process.env.OWNER_EMAIL || process.env.GMAIL_USER;
    if(!mailer || !to){ console.error('Webhook: sin Gmail/OWNER_EMAIL, no se pudo avisar del monto que no coincide.'); return; }
    const esperado = moneyMx(info.expectedCents / 100);
    const cobrado = moneyMx(info.receivedCents / 100);
    const dif = moneyMx((info.receivedCents - info.expectedCents) / 100);
    const html = layout({
      preheader: `Pedido ${orderNum}: Stripe cobró ${cobrado} y el pedido dice ${esperado}`,
      title: '⚠️ Un pago no coincide con el pedido',
      intro: `El pedido <b>${escHtml(orderNum)}</b> NO se marcó como pagado y no se crearon ventas ni correos. Revísalo a mano.`,
      body: table([
        pieceRow({ title: 'Total del pedido', sub: 'Lo que debía cobrarse', right: '<b>' + esperado + '</b>' }),
        pieceRow({ title: 'Cobrado por Stripe', sub: 'PaymentIntent ' + escHtml(info.paymentIntentId), right: '<b>' + cobrado + '</b>' }),
        pieceRow({ title: 'Diferencia', sub: 'Cliente: ' + escHtml(order.name || '—') + (order.email ? ' · ' + escHtml(order.email) : '') + (order.phone ? ' · ' + escHtml(order.phone) : ''), right: '<b>' + dif + '</b>' })
      ]) + note('Busca el PaymentIntent en tu Dashboard de Stripe y decide si reembolsas la diferencia o apruebas el pedido manualmente desde el panel.'),
      cta: 'Abrir Stripe',
      ctaUrl: 'https://dashboard.stripe.com/payments/' + encodeURIComponent(info.paymentIntentId)   // antes abría el portal de vendedores
    });
    await mailer.sendMail({
      from: `"ZAYDE" <${process.env.GMAIL_USER}>`,
      to,
      subject: `⚠️ Pago con monto distinto — pedido ${orderNum}`,
      html
    });
  }catch(e){
    console.error('Webhook: no se pudo mandar el aviso de amountMismatch al dueño:', e);
  }
}

// ============================================================
// [MEMBRESÍAS Y TARJETAS DE REGALO · EN EL SERVIDOR]
// Antes todo esto lo decidía el navegador (localStorage): cualquiera podía darse una membresía de paga o saldo
// de tarjeta sin pagar. Ahora solo se otorga aquí, cuando Stripe confirma el pago:
//   memberships/{uid}   -> la membresía de paga (el cliente solo la lee)
//   giftcards/{codigo}  -> las tarjetas emitidas (código aleatorio generado aquí)
//   giftBalances/{uid}  -> saldo disponible de cada cuenta (el cliente solo lo lee)
//   digitalFulfillments/{ref} -> plan privado e idempotente de lo que se entregó (Stripe puede reenviar el evento)
//   giftDebits/{paymentIntent} -> evita descontar dos veces el saldo usado en un pago
// ============================================================
function newGiftCode(){
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const pick = (n) => Array.from(crypto.randomBytes(n), (b) => A[b % A.length]).join('');
  return 'ZY-' + pick(4) + '-' + pick(4);
}


// [FIX — enlaces de correos al CLIENTE] Antes estos correos usaban layout() (plantilla del portal de
// VENDEDORES), cuyo botón siempre abría el portal. Ahora los correos al cliente usan _lib/zaydeEmail.js
// (estilo Fashion Nova), y TODOS sus botones apuntan a la tienda (SITE_URL).
function customerLayout({ preheader, title, intro, body, cta, ctaUrl }) {
  return simpleEmailHtml({ title: stripEmoji(title), intro, bodyHtml: body, cta, ctaUrl, preheader });
}

async function emailGiftCard(g, buyerName){
  const mailer = getMailer();
  if(!mailer || !g.email) throw new Error('No hay Gmail configurado o falta el correo del destinatario de la tarjeta ' + g.code);
  if(!(await canReceiveEmail(g.email))){ console.error('Webhook: correo de la tarjeta de regalo no válido, no se envía:', g.code, g.email); return; }
  const monto = moneyMx(g.amount);
  const intro = (buyerName ? escHtml(buyerName) + ' te regaló' : 'Te regalaron') + ' una tarjeta de regalo ZAYDE por <b>' + monto + '</b>. Inicia sesión en ZAYDE y canjea este código en tu cuenta:';
  let html;
  try{
    html = customerLayout({
      preheader: 'Tu tarjeta de regalo ZAYDE de ' + monto,
      title: '🎁 Tu tarjeta de regalo ZAYDE',
      intro,
      body: codeBox(g.code) + lightNote('El saldo se suma a tu cuenta y se aplica solo en tu próxima compra.'),
      cta: 'Ir a ZAYDE'
    });
  }catch(e){
    html = '<p>' + intro + '</p><p style="font-size:24px;letter-spacing:2px;"><b>' + escHtml(g.code) + '</b></p>';
  }
  await mailer.sendMail({ from: `"ZAYDE" <${process.env.GMAIL_USER}>`, to: g.email, subject: '🎁 Tu tarjeta de regalo ZAYDE de ' + monto, html });
}

async function emailMembership(base, tier){
  const mailer = getMailer();
  if(!mailer || !base.email) return false;
  const intro = '¡Bienvenido a ZAYDE Club! Tu membresía <b>' + escHtml(tier) + '</b> ya está activa en tu cuenta.';
  let html;
  try{
    html = customerLayout({ preheader: 'Tu membresía ' + tier + ' ya está activa', title: '✨ Bienvenido a ZAYDE Club', intro, body: lightNote('Inicia sesión para ver tus beneficios; el envío gratis se aplica solo en tu checkout.'), cta: 'Ir a ZAYDE' });
  }catch(e){ html = '<p>' + intro + '</p>'; }
  await mailer.sendMail({ from: `"ZAYDE" <${process.env.GMAIL_USER}>`, to: base.email, subject: '✨ Tu membresía ' + tier + ' de ZAYDE Club está activa', html });
  return true;
}

// Entrega lo digital de una compra (membresía y/o tarjetas). Idempotente: si Stripe reenvía el evento no duplica nada.
// opts.welcomeEmail: manda el correo de bienvenida de la membresía (solo compras DIG-…; en pedidos ya va en la confirmación).
async function grantDigital(db, ref, base, items, paymentIntent, opts){
  const docRef = db.collection('digitalFulfillments').doc(ref);
  const plan = await db.runTransaction(async (tx) => {
    const d = await tx.get(docRef);
    const cur = d.exists ? d.data() : {};
    if(cur.fulfillment) return cur.fulfillment;
    const p = { at: Date.now(), tier: null, gifts: [] };
    const m = items.find((it) => it && it.isMembership);
    if(m && base.uid) p.tier = String(m.tierName || '');
    items.filter((it) => it && it.isGiftCard).forEach((it) => {
      const n = Math.max(1, Math.min(20, Number(it.qty) || 1));
      for(let i = 0; i < n; i++) p.gifts.push({ code: newGiftCode(), amount: Math.round(Number(it.price) || 0), email: String(it.giftEmail || '').toLowerCase() || null, done: false });
    });
    tx.set(docRef, { fulfillment: p, ref, paymentIntentId: paymentIntent.id }, { merge: true });
    return p;
  });

  if(plan.tier && base.uid){
    await db.collection('memberships').doc(base.uid).set({ tier: plan.tier, joinedAt: plan.at, ref, paymentIntentId: paymentIntent.id, updatedAt: Date.now() });
  }

  let changed = false;
  if(opts && opts.welcomeEmail && plan.tier && base.uid && base.email && !plan.membershipEmailed){
    try{ if(await emailMembership(base, plan.tier)){ plan.membershipEmailed = true; changed = true; } }
    catch(e){ console.error('Webhook: no se pudo mandar el correo de bienvenida de la membresía:', e); }   // no es crítico
  }
  for(const g of plan.gifts){
    if(g.done || !(g.amount > 0)) continue;
    const cardRef = db.collection('giftcards').doc(g.code);
    try{
      await cardRef.create({ amount: g.amount, balance: g.amount, email: g.email, buyerUid: base.uid || null, buyerEmail: base.email || null, buyerName: base.name || null, ref, createdAt: Date.now(), redeemedBy: null });
    }catch(e){
      if(!(e && (e.code === 6 || /already exists/i.test(String(e.message))))) throw e;   // ya existía de un intento anterior
    }
    const toSelf = base.uid && g.email && base.email && g.email === String(base.email).toLowerCase();
    if(toSelf){
      // Se la regaló a sí mismo: el saldo se suma directo a su cuenta
      const balRef = db.collection('giftBalances').doc(base.uid);
      await db.runTransaction(async (tx) => {
        const [c, b] = await Promise.all([tx.get(cardRef), tx.get(balRef)]);
        if(!c.exists || c.data().redeemedBy) return;
        tx.update(cardRef, { redeemedBy: base.uid, redeemedAt: Date.now(), balance: 0 });
        const bd = b.exists ? b.data() : {};
        const cards = giftCardsOf(bd);
        cards.push({ id: crypto.createHash('sha256').update(g.code).digest('hex').slice(0, 12), last4: g.code.slice(-4), original: g.amount, balance: g.amount, createdAt: Number(c.data().createdAt) || Date.now(), redeemedAt: Date.now() });
        tx.set(balRef, { balance: (Number(bd.balance) || 0) + g.amount, cards, updatedAt: Date.now() }, { merge: true });
      });
    }else{
      await emailGiftCard(g, base.name);   // si falla, lanza error: Stripe reintenta y te llega la alerta
    }
    g.done = true; changed = true;
  }
  if(changed) await docRef.set({ fulfillment: plan }, { merge: true });
  return plan;
}

// [TARJETAS DE REGALO · LISTA POR TARJETA] giftBalances/{uid}.cards = una entrada por tarjeta canjeada
// ({ id, last4, original, balance, createdAt, redeemedAt }). El saldo total sigue en .balance.
function giftCardsOf(data){ return Array.isArray(data && data.cards) ? data.cards.map((c) => ({ ...c })) : []; }
function consumeGiftCards(cards, amount){   // la tarjeta más antigua se gasta primero
  let left = Math.round(amount * 100) / 100; const used = [];
  cards.sort((a, b) => (Number(a.redeemedAt) || 0) - (Number(b.redeemedAt) || 0));
  for(const c of cards){
    if(left <= 0) break;
    const b = Number(c.balance) || 0; if(b <= 0) continue;
    const t = Math.min(b, left);
    c.balance = Math.round((b - t) * 100) / 100; left = Math.round((left - t) * 100) / 100;
    used.push({ id: c.id, amount: t });
  }
  return used;
}

// Descuenta del saldo de tarjeta de regalo lo que se usó en un pago ya confirmado (una sola vez por pago).
// opts.strict: si el saldo no alcanza, NO descuenta y devuelve { ok:false } (pago 100% con saldo).
export async function debitGiftBalance(db, paymentIntentId, uid, amount, opts){
  const debitRef = db.collection('giftDebits').doc(paymentIntentId);
  const balRef = db.collection('giftBalances').doc(uid);
  return db.runTransaction(async (tx) => {
    const [d, b] = await Promise.all([tx.get(debitRef), tx.get(balRef)]);
    if(d.exists) return { ok: true, already: true };
    const data = b.exists ? b.data() : {};
    const cur = Number(data.balance) || 0;
    if(opts && opts.strict && cur < amount - 0.5) return { ok: false };
    const cards = giftCardsOf(data);
    const tracked = cards.reduce((a, c) => a + (Number(c.balance) || 0), 0);
    const legacy = Math.max(0, cur - tracked);                       // saldo anterior a la lista por tarjeta: se gasta primero
    const used = consumeGiftCards(cards, Math.max(0, Math.min(cur, amount) - legacy));
    tx.set(balRef, { balance: Math.max(0, cur - amount), cards, updatedAt: Date.now() }, { merge: true });
    tx.set(debitRef, { uid, amount, used, at: Date.now() });
    return { ok: true };
  });
}

// Deshace un descuento de saldo (solo si el pedido pagado con saldo no se pudo completar).
export async function undoGiftDebit(db, paymentIntentId, uid){
  const debitRef = db.collection('giftDebits').doc(paymentIntentId);
  const balRef = db.collection('giftBalances').doc(uid);
  await db.runTransaction(async (tx) => {
    const [d, b] = await Promise.all([tx.get(debitRef), tx.get(balRef)]);
    if(!d.exists) return;
    const dd = d.data(); const data = b.exists ? b.data() : {}; const cards = giftCardsOf(data);
    (dd.used || []).forEach((u) => { const c = cards.find((x) => x.id === u.id); if(c) c.balance = Math.round(((Number(c.balance) || 0) + Number(u.amount)) * 100) / 100; });
    tx.set(balRef, { balance: (Number(data.balance) || 0) + (Number(dd.amount) || 0), cards, updatedAt: Date.now() }, { merge: true });
    tx.delete(debitRef);
  });
}

// BIENVENIDO10 es de una sola vez por correo: se marca aquí, con el pago ya confirmado (create-payment-intent lo revisa).
async function markWelcomeCoupon(db, orderNum, order){
  const code = order.coupon && String(order.coupon.code || '').toUpperCase();
  const email = String(order.email || '').trim().toLowerCase();
  if(code !== 'BIENVENIDO10' || !email) return;
  await db.collection('couponRedemptions').doc('BIENVENIDO10__' + encodeURIComponent(email)).set({ code, email, orderNum, at: Date.now() }, { merge: true });
}

async function fulfillOrderDigital(db, orderNum, order, paymentIntent){
  const meta = paymentIntent.metadata || {};
  const items = (order.items || []).filter((it) => it && (it.isMembership || it.isGiftCard));
  if(items.length){
    await grantDigital(db, orderNum, { uid: meta.uid || null, email: order.email || null, name: order.name || null }, items, paymentIntent);
  }
  const used = Number(meta.giftUsed) || 0;
  if(used > 0 && meta.giftUid) await debitGiftBalance(db, paymentIntent.id, meta.giftUid, used);
  await markWelcomeCoupon(db, orderNum, order);
}

// [ALERTA DE FALLO] Si el webhook se cae procesando un evento de Stripe, te llega un correo simple
// (Stripe reintenta solo, pero así te enteras en vez de descubrirlo días después). Nunca rompe el webhook.
async function notifyOwnerWebhookFailure(event, err){
  try{
    const mailer = getMailer();
    const to = process.env.OWNER_EMAIL || process.env.GMAIL_USER;
    if(!mailer || !to) return;
    const pi = event && event.data && event.data.object;
    await mailer.sendMail({
      from: `"ZAYDE" <${process.env.GMAIL_USER}>`,
      to,
      subject: '🚨 Falló el webhook de Stripe (' + (event && event.type || 'evento desconocido') + ')',
      text: 'El webhook falló procesando un evento. Stripe lo reintentará, pero revisa los registros en Vercel.\n\n' +
        'Evento: ' + (event && event.id || '—') + '\nTipo: ' + (event && event.type || '—') + '\n' +
        'Pedido: ' + ((pi && pi.metadata && pi.metadata.orderNum) || '—') + '\n' +
        'Pago: ' + ((pi && (pi.payment_intent || pi.id)) || '—') + '\n' +
        'Error: ' + String((err && err.message) || err).slice(0, 500) + '\n'
    });
  }catch(e){
    console.error('Webhook: no se pudo mandar la alerta de fallo:', e);
  }
}

// [PEDIDOS PAGADOS · UN SOLO CAMINO] Cierra un pedido ya pagado: lo marca pagado, manda la confirmación, entrega lo digital,
// descuenta el saldo de tarjeta de regalo, crea las ventas de vendedor, historial de precios y avisos de stock. Lo usa el
// webhook de Stripe (paymentIntent real) y también el pago 100% con saldo de tarjeta de regalo (paymentIntent.gift = true,
// sin Stripe), así los dos pedidos terminan exactamente igual. Es idempotente.
export async function processPaidOrder(db, orderNum, paymentIntent){
      const orderRef = db.collection('orders').doc(orderNum);
      const snap = await orderRef.get();

      if(!snap.exists){
        // No debería pasar casi nunca (el pedido se guarda como "pendiente"
        // ANTES de cobrar), pero por si acaso: se registra el error para
        // poder investigarlo manualmente en vez de perder el rastro del pago.
        console.error(`Webhook: no se encontró el pedido ${orderNum} en Firestore para el pago ${paymentIntent.id}.`);
        return { warning: 'pedido no encontrado' };
      }

      const order = snap.data();

      // [SEGURIDAD · MONTO] Antes de marcar el pedido como pagado, el dinero que Stripe
      // SÍ cobró debe coincidir con el total del pedido (tolerancia de $1 por redondeo).
      // Si alguien manipuló el monto del cobro desde el navegador, el pedido NO se marca
      // pagado, no se crean ventas ni se manda correo: queda con la bandera "amountMismatch"
      // para revisarlo a mano (y el pago aparece en tu Dashboard de Stripe).
      if(order.paymentStatus !== 'pagado'){
        const expectedCents = Math.round(Number(order.total) * 100);
        const receivedCents = Number(paymentIntent.amount_received != null ? paymentIntent.amount_received : paymentIntent.amount);
        if(!isFinite(expectedCents) || !isFinite(receivedCents) || Math.abs(receivedCents - expectedCents) > 100){
          console.error(`Webhook: MONTO NO COINCIDE en el pedido ${orderNum} — Stripe cobró ${receivedCents} centavos y el pedido dice ${expectedCents}. NO se marca como pagado. PaymentIntent ${paymentIntent.id}.`);
          await orderRef.update({ amountMismatch: { receivedCents, expectedCents, paymentIntentId: paymentIntent.id, at: Date.now() } });
          await notifyOwnerAmountMismatch(order, orderNum, { receivedCents, expectedCents, paymentIntentId: paymentIntent.id });
          return { warning: 'monto no coincide' };
        }
      }

      // Idempotencia: Stripe puede reenviar el mismo evento más de una vez.
      // Si ya estaba marcado como pagado (porque el navegador del cliente sí
      // alcanzó a hacerlo), no se hace nada más — así nunca se manda un
      // correo de confirmación duplicado.
      if(order.paymentStatus !== 'pagado'){
        await orderRef.update({
          paymentStatus: 'pagado',
          ...(paymentIntent.gift ? { paidWithGift: true, paidAt: Date.now() } : { stripePaymentIntentId: paymentIntent.id }),
          paymentFailReason: admin.firestore.FieldValue.delete() // limpia un posible intento fallido anterior del mismo pedido
        });
        await sendBackupConfirmationEmail({ ...order, ...(paymentIntent.gift ? { paidWithGift: true } : { stripePaymentIntentId: paymentIntent.id }) });
      }

      // [VENDEDORES] Crea las filas de sellerSales de este pedido. Va FUERA
      // del "if" de arriba a propósito: si un intento anterior marcó el
      // pedido como pagado pero falló antes de registrar las ventas (y
      // Stripe reintenta), aquí se completan sin duplicar nada.
      // [MEMBRESÍAS / TARJETAS / SALDO] Lo digital del pedido y el saldo de tarjeta de regalo usado (idempotente).
      await fulfillOrderDigital(db, orderNum, order, paymentIntent);

      const salesCreated = await createSellerSales(db, orderNum, order, paymentIntent);
      if(salesCreated) console.log(`Webhook: ${salesCreated} venta(s) de vendedor registradas para el pedido ${orderNum}.`);

      // [SEGURIDAD] Historial de precios (gráfica pública de cada producto). Antes lo
      // escribía el navegador del comprador y las reglas lo dejaban abierto a cualquiera,
      // así que se podían inventar precios. Ahora solo se registra aquí, con el pago ya
      // confirmado por Stripe. El ID es fijo (pedido + posición): si Stripe reenvía el
      // evento, se sobrescribe el mismo registro y no se duplica. Si falla, no se rompe
      // el webhook: solo se anota el error.
      try{
        const histItems = (order.items || []).filter(it => it && it.id != null && !it.isMembership && !it.isGiftCard && Number(it.price) > 0);
        if(histItems.length){
          const hb = db.batch();
          histItems.forEach((it, i) => {
            hb.set(db.collection('priceHistory').doc(`${orderNum}_${i}`), {
              productId: String(it.id), price: Number(it.price), date: Number(order.date) || Date.now()
            });
          });
          await hb.commit();
        }
      }catch(e){ console.error('Webhook: no se pudo guardar el historial de precios:', e); }

      // [VENDEDORES] Aviso de stock bajo: si esta compra dejó a una talla de un
      // vendedor en 1 unidad o en 0, se le avisa por correo. Comparte la lógica
      // (y el tope de 6 h por pieza/talla) con /api/send-email type
      // "seller-low-stock", así que si el navegador también lo pide, el
      // vendedor recibe un solo correo. Si esto falla NO se rompe el webhook
      // (la venta ya quedó registrada): solo se anota el error.
      try{
        const physicalItems = (order.items || [])
          .filter(it => it && it.sellerId && it.id != null && it.size && !it.isMembership && !it.isGiftCard)
          .map(it => ({ id: it.id, size: it.size, qty: it.qty }));
        if(physicalItems.length){
          await notifySellerLowStock(db, physicalItems, { mailer: getMailer() });
        }
      }catch(e){ console.error('Webhook: error en el aviso de stock bajo a vendedores:', e); }
  return { ok: true };
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).send('Método no permitido');
    return;
  }

  if(!process.env.STRIPE_WEBHOOK_SECRET || !process.env.STRIPE_SECRET_KEY){
    console.error('Webhook: faltan STRIPE_WEBHOOK_SECRET o STRIPE_SECRET_KEY en Vercel.');
    res.status(500).send('Falta configuración del servidor.');
    return;
  }

  let event;
  try{
    const rawBody = await readRawBody(req);
    const signature = req.headers['stripe-signature'];
    event = stripe.webhooks.constructEvent(rawBody, signature, process.env.STRIPE_WEBHOOK_SECRET);
  }catch(err){
    // Firma inválida: alguien (o algo) que no es Stripe de verdad está
    // llamando a esta URL — se rechaza, no se procesa nada.
    console.error('Webhook: firma inválida —', err.message);
    res.status(400).send(`Webhook Error: ${err.message}`);
    return;
  }

  try{
    if(event.type === 'payment_intent.succeeded'){
      const paymentIntent = event.data.object;
      const orderNum = paymentIntent.metadata && paymentIntent.metadata.orderNum;

      if(!orderNum){
        console.error('Webhook: el PaymentIntent', paymentIntent.id, 'no trae orderNum en metadata — no se puede confirmar ningún pedido.');
        res.status(200).json({ received: true, warning: 'sin orderNum' });
        return;
      }

      const db = getFirestore();

      // [COMPRAS DIGITALES] Una referencia DIG-… es una membresía y/o tarjeta de regalo comprada sin pedido. Se entrega
      // aquí, con el pago ya confirmado por Stripe y contra lo que el servidor registró al crear el cobro.
      if(String(orderNum).startsWith('DIG-')){
        const dSnap = await db.collection('digitalPurchases').doc(orderNum).get();
        if(!dSnap.exists){
          console.error(`Webhook: pago digital ${orderNum} (${paymentIntent.id}) sin registro en digitalPurchases.`);
          await notifyOwnerWebhookFailure(event, new Error('Pago digital sin registro: ' + orderNum));
          res.status(200).json({ received: true, warning: 'compra digital sin registro' });
          return;
        }
        const dp = dSnap.data();
        const receivedCents = Number(paymentIntent.amount_received != null ? paymentIntent.amount_received : paymentIntent.amount);
        if(!isFinite(receivedCents) || Math.abs(receivedCents - Number(dp.amountCents)) > 100){
          console.error(`Webhook: MONTO NO COINCIDE en la compra digital ${orderNum} — cobrado ${receivedCents}, esperado ${dp.amountCents}.`);
          await notifyOwnerAmountMismatch({ name: dp.buyerName, email: dp.buyerEmail }, orderNum, { receivedCents, expectedCents: Number(dp.amountCents), paymentIntentId: paymentIntent.id });
          res.status(200).json({ received: true, warning: 'monto no coincide' });
          return;
        }
        await grantDigital(db, orderNum, { uid: dp.uid || null, email: dp.buyerEmail || dp.email || null, name: dp.buyerName || null }, dp.items || [], paymentIntent, { welcomeEmail: true });
        res.status(200).json({ received: true, digital: true });
        return;
      }

      const r = await processPaidOrder(db, orderNum, paymentIntent);
      if(r && r.warning){ res.status(200).json({ received: true, warning: r.warning }); return; }
    }

    // [NUEVO] Pago rechazado: el banco/Stripe no autorizó el cobro (fondos
    // insuficientes, antifraude, tarjeta vencida, etc.). El pedido NO se
    // pierde — sigue existiendo como "pendiente" en Firestore desde que se
    // creó antes de cobrar — pero antes no había ninguna señal de que el
    // pago había fallado: ni el cliente se enteraba claramente (si cerraba
    // la pestaña del checkout), ni tú lo veías distinto a un pedido
    // cualquiera "pendiente" en el panel.
    if(event.type === 'payment_intent.payment_failed'){
      const paymentIntent = event.data.object;
      const orderNum = paymentIntent.metadata && paymentIntent.metadata.orderNum;

      if(!orderNum){
        console.error('Webhook: PaymentIntent fallido', paymentIntent.id, 'sin orderNum en metadata.');
        res.status(200).json({ received: true, warning: 'sin orderNum' });
        return;
      }

      const db = getFirestore();
      const orderRef = db.collection('orders').doc(orderNum);
      const snap = await orderRef.get();

      if(!snap.exists){
        console.error(`Webhook: no se encontró el pedido ${orderNum} para el pago fallido ${paymentIntent.id}.`);
        res.status(200).json({ received: true, warning: 'pedido no encontrado' });
        return;
      }

      const order = snap.data();
      const reason = humanDeclineReason(paymentIntent);

      // Si el pedido YA está pagado (ej. el cliente reintentó y la segunda
      // vez sí funcionó, y ese evento de éxito llegó primero), no lo
      // pisamos con "fallido" — solo se registra el intento fallido si el
      // pedido sigue sin pagarse.
      if(order.paymentStatus !== 'pagado'){
        await orderRef.update({
          paymentStatus: 'fallido',
          paymentFailReason: reason || 'motivo no especificado',
          paymentFailedAt: Date.now()
        });
        await sendPaymentFailedEmail({ ...order }, reason);
      }
    }

    // [REEMBOLSOS] Un reembolso hecho desde el Dashboard de Stripe ya no se pierde: si fue TOTAL, las
    // ventas de vendedor de ese pago pasan a "devuelta" (y se le avisa al vendedor); si fue PARCIAL,
    // solo se anota en el pedido y queda un aviso en los registros para revisarlo a mano.
    if(event.type === 'charge.refunded'){
      const charge = event.data.object;
      const db = getFirestore();
      const r = await applyStripeRefund(db, getMailer(), charge);
      console.log(`Webhook: reembolso del pago ${charge.payment_intent || charge.id} — ${r.mode}, ${r.updated} venta(s) de vendedor actualizadas, ${r.sent} aviso(s) enviados.`);
    }

    res.status(200).json({ received: true });
  }catch(err){
    console.error('Webhook: error procesando el evento:', err);
    await notifyOwnerWebhookFailure(event, err);
    // 500 le dice a Stripe "algo salió mal, reinténtalo más tarde" —
    // Stripe reintenta automáticamente los webhooks que fallan.
    res.status(500).json({ error: 'Error procesando el webhook.' });
  }
}
