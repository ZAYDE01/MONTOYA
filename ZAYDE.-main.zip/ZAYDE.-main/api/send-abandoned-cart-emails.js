// api/send-abandoned-cart-emails.js
//
// Manda un correo de recordatorio a los carritos que quedaron a medias:
// el cliente escribió su email en el checkout (ver zySaveAbandonedCart en
// index.html) pero nunca confirmó la orden.
//
// NO se llama desde el navegador — es un endpoint protegido que se llama
// por cron (Vercel Cron Jobs, ver vercel.json), una vez por hora.
//
// ---- Variables de entorno (las mismas de antes, sin nada nuevo) ----
//      GMAIL_USER, GMAIL_APP_PASSWORD, FIREBASE_SERVICE_ACCOUNT_B64, CRON_SECRET
//
// ---- CAMBIOS DE SEGURIDAD EN ESTA VERSIÓN ----
// Los datos del carrito los escribe el NAVEGADOR (cualquiera puede escribir en
// "abandonedCarts" con el correo que quiera), así que aquí NO se confía en ellos:
//   1) Todo texto (nombre, marca, talla) se limpia y se escapa antes de ir al HTML
//      del correo (antes se insertaba tal cual: se podía meter HTML/enlaces).
//   2) El total se RECALCULA con precio × cantidad ya validados (antes se usaba el
//      "total" que mandaba el navegador). Precios/cantidades fuera de rango se descartan.
//   3) El correo debe ser válido y sin caracteres raros, y debe coincidir con el ID del
//      documento (encodeURIComponent(correo en minúsculas)).
//   4) Tope de frecuencia por correo: máximo 1 recordatorio cada 14 días, llevado en una
//      colección SOLO de servidor ("abandonedCartsSent"). Antes el navegador podía poner
//      emailSent:false otra vez y hacer que a alguien le llegara un correo cada pocas horas.
//   5) Tope de correos por ejecución (100) y máximo 20 artículos por carrito.
// La colección "abandonedCartsSent" NO necesita regla: la regla final de firestore.rules
// la deja cerrada a clientes y el Admin SDK (este archivo) la usa sin problema.

import nodemailer from 'nodemailer';
import admin from 'firebase-admin';

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(
      JSON.parse(
        Buffer.from(process.env.FIREBASE_SERVICE_ACCOUNT_B64, 'base64').toString('utf-8')
      )
    ),
  });
}
const db = admin.firestore();

let cachedTransporter = null;
function getTransporter(){
  if(cachedTransporter) return cachedTransporter;
  cachedTransporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.GMAIL_USER,
      pass: process.env.GMAIL_APP_PASSWORD
    }
  });
  return cachedTransporter;
}

// No mandar antes de que pase este tiempo desde la última vez que se tocó
// el carrito (para no molestar a alguien que sigue comprando en ese momento),
// ni después de este otro (un carrito de hace 5 días ya no vale la pena).
const MIN_AGE_MS = 2 * 60 * 60 * 1000;        // 2 horas
const MAX_AGE_MS = 5 * 24 * 60 * 60 * 1000;   // 5 días
const COOLDOWN_MS = 14 * 24 * 60 * 60 * 1000; // máximo 1 recordatorio por correo cada 14 días
const MAX_SENDS_PER_RUN = 100;
const MAX_ITEMS = 20;

const SITE_URL = 'https://zayde-kappa.vercel.app'; // [AJUSTA si tu dominio final es otro, ej. zayde.com.mx]

// ---- Limpieza de datos que vienen del navegador ----
const escHtml = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
));
const cleanText = (v, max) => String(v == null ? '' : v).replace(/\s+/g, ' ').trim().slice(0, max);

// Correo sin espacios, comas, punto y coma, <>, comillas ni paréntesis (así no se puede
// colar una lista de destinatarios ni un "Nombre <correo>").
const SAFE_EMAIL = /^[^\s@,;<>"'()\[\]\\]{1,64}@[^\s@,;<>"'()\[\]\\]{1,190}\.[^\s@,;<>"'()\[\]\\]{2,}$/;

function cleanItems(raw) {
  if (!Array.isArray(raw)) return [];
  const out = [];
  for (const it of raw.slice(0, MAX_ITEMS)) {
    if (!it || typeof it !== 'object') continue;
    const price = Number(it.price);
    const qty = Math.round(Number(it.qty));
    const name = cleanText(it.name, 80);
    if (!name) continue;
    if (!isFinite(price) || price < 0 || price > 1000000) continue;
    if (!isFinite(qty) || qty < 1 || qty > 20) continue;
    out.push({ name, brand: cleanText(it.brand, 40), size: cleanText(it.size, 12), price, qty });
  }
  return out;
}

function fmtMXN(n) {
  return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN', maximumFractionDigits: 0 }).format(n);
}

// items ya vienen limpios (cleanItems); aun así todo texto se escapa al meterlo en el HTML.
function buildEmailHTML(items, total) {
  const rows = items.map(it => `
    <tr>
      <td style="padding:8px 0;font-size:14px;color:#0E0E10;">
        ${it.brand ? `${escHtml(it.brand)} — ` : ''}${escHtml(it.name)}${it.size ? ` · Talla ${escHtml(it.size)}` : ''}${it.qty > 1 ? ` × ${it.qty}` : ''}
      </td>
      <td style="padding:8px 0;font-size:14px;color:#0E0E10;text-align:right;white-space:nowrap;">
        ${fmtMXN(it.price * it.qty)}
      </td>
    </tr>`).join('');

  return `
  <div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;">
    <h2 style="font-size:18px;letter-spacing:-.01em;">Dejaste algo en tu carrito</h2>
    <p style="font-size:14px;color:#555;line-height:1.5;">
      Tus piezas siguen apartadas, pero el stock es limitado — algunas tallas
      pueden agotarse. Retómalo cuando quieras:
    </p>
    <table style="width:100%;border-collapse:collapse;margin:16px 0;">
      ${rows}
      <tr><td style="padding-top:10px;font-size:14px;font-weight:700;">Total</td>
          <td style="padding-top:10px;font-size:14px;font-weight:700;text-align:right;">${fmtMXN(total)}</td></tr>
    </table>
    <a href="${SITE_URL}" style="display:inline-block;background:#0E0E10;color:#fff;text-decoration:none;
       padding:12px 22px;border-radius:4px;font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.03em;">
      Volver a mi carrito
    </a>
    <p style="font-size:11px;color:#999;margin-top:24px;">
      Recibiste este correo porque dejaste tu email al iniciar una compra en ZAYDE.
      Si no quieres recibir estos recordatorios, responde a este correo con la palabra NO.
    </p>
  </div>`;
}

export default async function handler(req, res) {
  const secret = req.query.secret || (req.headers.authorization || '').replace('Bearer ', '');
  if (!process.env.CRON_SECRET || secret !== process.env.CRON_SECRET) {
    return res.status(401).json({ error: 'No autorizado' });
  }

  if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) {
    return res.status(500).json({ error: 'Faltan GMAIL_USER / GMAIL_APP_PASSWORD en las variables de entorno de Vercel.' });
  }

  try {
    const now = Date.now();
    const snap = await db.collection('abandonedCarts')
      .where('status', '==', 'pending')
      .where('emailSent', '==', false)
      .get();

    let sent = 0, skipped = 0;
    for (const doc of snap.docs) {
      if (sent >= MAX_SENDS_PER_RUN) { skipped++; continue; }

      const cartDoc = doc.data();
      const email = String(cartDoc.email || '').trim();
      const age = now - (Number(cartDoc.updatedAt) || 0);
      const items = cleanItems(cartDoc.items);

      // Datos inválidos o fuera de ventana de tiempo
      if (!SAFE_EMAIL.test(email) || email.length > 200) { skipped++; continue; }
      if (doc.id !== encodeURIComponent(email.toLowerCase())) { skipped++; continue; }  // el ID debe ser el correo
      if (age < MIN_AGE_MS || age > MAX_AGE_MS || !items.length) { skipped++; continue; }

      // Tope de frecuencia (colección solo de servidor): 1 recordatorio por correo cada 14 días
      const logRef = db.collection('abandonedCartsSent').doc(doc.id);
      const logSnap = await logRef.get();
      if (logSnap.exists && now - (Number(logSnap.data().lastSentAt) || 0) < COOLDOWN_MS) {
        await doc.ref.set({ emailSent: true }, { merge: true });   // no se vuelve a revisar en cada corrida
        skipped++;
        continue;
      }

      const total = items.reduce((sum, it) => sum + it.price * it.qty, 0);   // total recalculado, no el del navegador

      try {
        await getTransporter().sendMail({
          from: `"ZAYDE" <${process.env.GMAIL_USER}>`,
          to: email,
          subject: 'Dejaste algo en tu carrito — ZAYDE',
          html: buildEmailHTML(items, total),
        });
        await logRef.set({ lastSentAt: now });
        await doc.ref.set({ emailSent: true, emailSentAt: now }, { merge: true });
        sent++;
      } catch (sendErr) {
        console.error('No se pudo enviar recordatorio a', email, sendErr);
      }
    }

    return res.status(200).json({ ok: true, sent, skipped, checked: snap.size });
  } catch (e) {
    console.error('Error en send-abandoned-cart-emails:', e);
    return res.status(500).json({ error: 'Error interno' });
  }
}
