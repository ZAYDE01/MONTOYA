// ============================================================
// [STRIPE] Backend real de cobro — crea el PaymentIntent en Stripe.
//
// Cómo activarlo en Vercel:
// 1) Sube este archivo a tu repo dentro de la carpeta /api (misma carpeta
//    donde vive tu index.html, es decir: /api/create-payment-intent.js).
//    Vercel detecta automáticamente cualquier archivo dentro de /api como
//    una función serverless — no necesitas configuración extra.
// 2) En tu proyecto de Vercel: Settings > Environment Variables, agrega:
//      STRIPE_SECRET_KEY = sk_test_xxxxx  (o sk_live_xxxxx cuando ya cobres real)
// 3) Vuelve a desplegar el proyecto (Vercel > Deployments > Redeploy) para
//    que la variable de entorno quede activa.
// 4) En tu index.html, reemplaza STRIPE_PUBLISHABLE_KEY por tu llave
//    pública (pk_test_xxxxx o pk_live_xxxxx) del mismo Dashboard de Stripe.
//
// Esta función NUNCA expone tu llave secreta al navegador: vive solo aquí,
// en el servidor, protegida por la variable de entorno.
//
// NOVEDAD: ahora manda el orderNum como "metadata" al crear el pago en
// Stripe. Eso es lo que le permite a /api/stripe-webhook.js identificar a
// qué pedido de Firestore pertenece un pago cuando Stripe le avisa "este
// pago se completó" — sin depender de que el navegador del cliente siga
// vivo para hacer esa conexión.
//
// [NUEVO] Rate limiting: máximo 10 intentos de cobro por IP cada 10
// minutos. Sin esto, cualquiera podía llamar a esta función sin límite —
// no roba dinero directamente (Stripe siempre cobra con datos de tarjeta
// reales), pero sí puede saturar tu cuenta de Stripe con intentos
// fallidos o usarla para probar números de tarjeta robados ("card
// testing"), un abuso común contra endpoints de pago sin límite.
//
// [NUEVO] Ahora esta misma función también responde a GET
// (/api/create-payment-intent?paymentIntentId=pi_xxx) para devolver la
// MARCA y ÚLTIMOS 4 DÍGITOS de la tarjeta con la que se pagó (ej. "visa",
// "4242"). Se juntó aquí en vez de crear un archivo nuevo para no volver
// a pasar el límite de 12 funciones de Vercel Hobby. Nunca se devuelve el
// número completo de la tarjeta — eso Stripe no lo expone ni con la
// llave secreta una vez procesado el pago.
// ============================================================

const admin = require('firebase-admin');
const crypto = require('crypto');
const { checkRateLimit } = require('./_lib/rateLimit');

function getFirebaseAdmin() {
  if (admin.apps.length) return admin;
  let credential;
  if (process.env.FIREBASE_SERVICE_ACCOUNT_B64) {
    const json = JSON.parse(Buffer.from(process.env.FIREBASE_SERVICE_ACCOUNT_B64, 'base64').toString('utf8'));
    credential = admin.credential.cert(json);
  } else {
    credential = admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n'),
    });
  }
  admin.initializeApp({ credential });
  return admin;
}

// [SESIÓN VERIFICADA] El navegador manda su token de Firebase; aquí se comprueba con Firebase Admin. Así el servidor
// sabe de verdad QUIÉN compra (membresías, saldo de tarjetas de regalo) sin confiar en lo que diga el navegador.
async function verifiedUser(idToken) {
  if (!idToken || typeof idToken !== 'string') return null;
  try {
    const d = await getFirebaseAdmin().auth().verifyIdToken(idToken);
    return { uid: d.uid, email: d.email || null };
  } catch (e) { return null; }
}

// ============================================================
// [SEGURIDAD · PRECIOS EN EL SERVIDOR]
// El navegador manda los precios, cupones y saldos; todo eso se puede editar desde la
// consola. Aquí el servidor los revisa contra Firestore (admin_products + admin_overrides)
// antes de crear el cobro. Regla: lo que paga el cliente no puede ser MENOR que
//   (precio real de cada pieza × cantidad) − (descuento máximo que le corresponde).
// ============================================================
const COUPON_DEFAULTS = { 'BIENVENIDO10': { type: 'pct', value: 10 }, 'ZAYDE50': { type: 'fixed', value: 50 }, 'ENVIOGRATIS': { type: 'freeship', value: 0 } };
const DEFAULT_TIER_PRICES = { 'Member': 0, 'Icon': 199, 'Icon Black': 499 };
// [ENVÍO EN EL SERVIDOR] Mismos números que index.html: envío gratis desde $2,000 y, debajo de eso, tarifa plana de $270
// (todo es terrestre, 3–5 días hábiles). Si cambias esos valores en el sitio, cámbialos aquí también.
const FREE_SHIP_THRESHOLD = 2000;   // envío gratis desde $2,000 (igual que ZY_FREE_SHIP_THRESHOLD en index.html)
const MIN_SHIPPING = 270;          // tarifa plana debajo del envío gratis (igual que ZY_FLAT_SHIPPING en index.html)
const MEMBERSHIP_CYCLE_MS = 30 * 24 * 60 * 60 * 1000; // igual que ZY_CLUB_CYCLE_MS en index.html
// Pon true cuando quieras volver a vender Icon / Icon Black (y también ZY_PAID_MEMBERSHIPS_ENABLED = true en index.html).
const PAID_MEMBERSHIPS_ENABLED = false;
// [NIVELES DEL CLUB] El sitio usa estos niveles "recomendados" mientras los ajustes guardados en el panel no tengan la
// bandera clubTiersV = 2 (ver zyMigrateHomeSettings en index.html). El servidor debe aplicar exactamente la misma regla;
// si no, validaba contra niveles viejos guardados y rechazaba el precio que el sitio mostraba ("el precio no coincide").
const TIERS_RECOMMENDED = [
  { name: 'Member', price: 'Gratis' },
  { name: 'Icon', price: '$199 MXN / mes', freeShipMin: 1300 },
  { name: 'Icon Black', price: '$499 MXN / mes', freeShipMin: 1000 },
];
// [SOLO MÉXICO] Mismas reglas que el sitio (index.html): estado de la lista, código postal que exista en México y, si hay pin,
// que caiga dentro de México. Los pedidos solo de membresía/tarjeta (sin envío) y la recolección en sucursal no se revisan aquí.
const MX_STATES = ['Aguascalientes','Baja California','Baja California Sur','Campeche','Chiapas','Chihuahua','Ciudad de México','Coahuila','Colima','Durango','Estado de México','Guanajuato','Guerrero','Hidalgo','Jalisco','Michoacán','Morelos','Nayarit','Nuevo León','Oaxaca','Puebla','Querétaro','Quintana Roo','San Luis Potosí','Sinaloa','Sonora','Tabasco','Tamaulipas','Tlaxcala','Veracruz','Yucatán','Zacatecas'];
const MX_ZIP_PREFIXES = [[1,16],[20,99]];
const MX_BBOX = { latMin: 14.3, latMax: 32.9, lngMin: -118.7, lngMax: -86.4 };
function mexicoError(order, priv) {
  const items = Array.isArray(order.items) ? order.items : [];
  if (!items.some(it => it && !it.isMembership && !it.isGiftCard)) return null;
  if (order.shipMode === 'sucursal') return null;
  if (!MX_STATES.includes(order.state)) return 'Por ahora solo enviamos dentro de México.';
  const zip = String(order.zip || '');
  const p = parseInt(zip.slice(0, 2), 10);
  if (!/^\d{5}$/.test(zip) || !MX_ZIP_PREFIXES.some(r => p >= r[0] && p <= r[1])) return 'Revisa tu código postal: solo enviamos dentro de México.';
  const c = priv && priv.deliveryCoords;
  if (c && !(c.lat >= MX_BBOX.latMin && c.lat <= MX_BBOX.latMax && c.lng >= MX_BBOX.lngMin && c.lng <= MX_BBOX.lngMax)) return 'La ubicación de entrega está fuera de México.';
  return null;
}

function effectiveClubTiers(hs) {
  if (!hs || hs.clubTiersV !== 2) return TIERS_RECOMMENDED;
  return Array.isArray(hs.clubTiers) ? hs.clubTiers : TIERS_RECOMMENDED;
}

async function metaValue(db, key) {
  try {
    const d = await db.collection('admin_meta').doc(encodeURIComponent(key)).get();
    return d.exists ? d.data().value : null;
  } catch (e) { return null; }
}
function priceNumber(str) { const n = parseFloat(String(str == null ? '' : str).replace(/[^0-9.]/g, '')); return isFinite(n) ? n : 0; }

async function verifyOrderPricing(db, order, ctx) {
  const items = Array.isArray(order.items) ? order.items : null;
  if (!items || !items.length || items.length > 30) return { ok: false, msg: 'Tu pedido no tiene piezas válidas.' };
  const ids = [...new Set(items.map(it => String(it && it.id)))];
  const [pSnaps, oSnaps] = await Promise.all([
    db.getAll(...ids.map(id => db.collection('admin_products').doc(id))),
    db.getAll(...ids.map(id => db.collection('admin_overrides').doc(id))),
  ]);
  const prod = {};
  ids.forEach((id, i) => {
    if (!pSnaps[i].exists) return;
    const ov = oSnaps[i].exists ? oSnaps[i].data() : {};
    prod[id] = ov._deleted ? null : Object.assign({}, pSnaps[i].data(), ov);
  });

  // Ajustes del Club (niveles y su mínimo de envío gratis): se leen una sola vez.
  const hs = await metaValue(db, 'zayde:admin:homeSettings');
  let tiers = null;
  let subtotal = 0;
  let physicalSubtotal = 0; // solo piezas físicas: las membresías y tarjetas de regalo no cuentan para el envío gratis
  for (const it of items) {
    const qty = Number(it && it.qty), price = Number(it && it.price);
    if (!it || !Number.isInteger(qty) || qty < 1 || qty > 50 || !isFinite(price) || price < 0) {
      return { ok: false, msg: 'Hay una pieza con datos inválidos en tu pedido.' };
    }
    const p = prod[String(it.id)];
    if (p) {
      // precio real: el de la talla/presentación si existe, si no el general (igual que el sitio)
      const sp = p.sizePrices;
      const unit = (sp && it.size && Number(sp[it.size]) > 0) ? Number(sp[it.size]) : Number(p.price);
      if (!isFinite(unit) || unit <= 0 || price < unit - 1) {
        return { ok: false, msg: 'El precio de “' + (p.name || 'una pieza') + '” cambió. Recarga la página para ver el precio actualizado.', log: { id: it.id, enviado: price, real: unit } };
      }
      subtotal += unit * qty;
      physicalSubtotal += unit * qty;
    } else if (it.isMembership) {
      // membresía: no puede costar menos que el precio de su nivel
      if (!tiers) {
        tiers = Object.assign({}, DEFAULT_TIER_PRICES);
        effectiveClubTiers(hs).forEach(t => { if (t && t.name) tiers[t.name] = t.price === 'Gratis' ? 0 : (String(t.price || '').replace(/[^\d]/g, '') ? parseInt(String(t.price).replace(/[^\d]/g, ''), 10) : 0); });   // mismo cálculo que zyParseTierAmount del sitio
      }
      const tierPrice = tiers[it.tierName];
      // [MEMBRESÍAS DE PAGA · PAUSADAS] Mientras estén en pausa no se cobra ninguna (el sitio ya las oculta; esto lo cierra en el servidor).
      if (!PAID_MEMBERSHIPS_ENABLED && tierPrice > 0) return { ok: false, msg: 'Las membresías de paga estarán disponibles pronto.', log: { tier: it.tierName } };
      if (tierPrice === undefined || price < tierPrice - 1) return { ok: false, msg: 'El precio de la membresía no coincide. Recarga la página e inténtalo de nuevo.', log: { tier: it.tierName, enviado: price, real: tierPrice } };
      subtotal += price * qty;
    } else if (it.isGiftCard) {
      if (price < 1) return { ok: false, msg: 'Monto de tarjeta de regalo inválido.' };
      subtotal += price * qty; // Fase 2: la tarjeta se emitirá desde el servidor
    } else {
      return { ok: false, msg: 'Una de las piezas de tu pedido ya no está disponible.', log: { id: it.id } };
    }
  }

  // Descuento máximo permitido
  const code = order.coupon && order.coupon.code ? String(order.coupon.code).toUpperCase() : '';
  let maxDiscount = 0;
  let freeShipCoupon = false;
  if (code) {
    const saved = (await metaValue(db, 'zayde:admin:coupons')) || {};
    const socio = (await metaValue(db, 'zayde:admin:socioCoupons')) || {};
    const c = Object.assign({}, COUPON_DEFAULTS, saved, socio)[code];
    const val = c ? Number(c.value) : NaN;
    if (c && c.type === 'pct' && isFinite(val)) maxDiscount = Math.round(subtotal * val / 100);
    else if (c && c.type === 'fixed' && isFinite(val)) maxDiscount = Math.min(subtotal, val);
    else if (c && c.type === 'freeship') { maxDiscount = 0; freeShipCoupon = true; }
    else {
      // [CUPONES] Un código que no está en tu lista ya NO recibe ningún descuento: antes cualquier código inventado
      // daba hasta 10%. Solo valen los de COUPON_DEFAULTS y los guardados en el panel (cupones y cupones de socios).
      return { ok: false, msg: 'El código de descuento no es válido. Quítalo e inténtalo de nuevo.', log: { code } };
    }
  }

  // [TARJETAS DE REGALO · SALDO] El saldo vive en el servidor (giftBalances/{uid}); aquí solo se acepta si la sesión
  // verificada tiene saldo suficiente. El descuento real del saldo lo hace el webhook cuando Stripe confirma el pago.
  const gift = Number(order.giftCardUsed) || 0;
  if (gift > 0 && !(ctx && Number(ctx.giftBalance) >= gift - 0.5)) {
    return { ok: false, msg: 'No pudimos verificar tu saldo de tarjeta de regalo. Inicia sesión, o quita el saldo e inténtalo de nuevo.', log: { gift, saldo: ctx && ctx.giftBalance } };
  }
  // [ENVÍO] El envío tampoco se confía al navegador. Ahora la membresía vive en el servidor, así que el mínimo de envío
  // gratis es exacto: el del nivel de PAGA vigente de la sesión verificada (ctx.memberTier), o el público para todos los demás.
  const allDigital = items.every(it => it && (it.isMembership || it.isGiftCard));
  const tierList = effectiveClubTiers(hs);
  let freeFrom = FREE_SHIP_THRESHOLD;
  if (ctx && ctx.memberTier) {
    const t = tierList ? tierList.find(x => x && x.name === ctx.memberTier) : null;
    if (!tierList) freeFrom = 0; // no hay niveles guardados: no se rechaza a un miembro legítimo
    else if (t && String(t.price || '').trim().toLowerCase() !== 'gratis') {
      const m = (t.freeShipMin !== undefined && t.freeShipMin !== '') ? Number(t.freeShipMin) : 0;
      freeFrom = Math.min(FREE_SHIP_THRESHOLD, (isFinite(m) && m >= 0) ? m : 0);   // un nivel nunca exige más que el público
    }
  }
  const minShipping = (allDigital || freeShipCoupon || physicalSubtotal >= freeFrom) ? 0 : MIN_SHIPPING;
  const floor = Math.max(0, subtotal - maxDiscount) + minShipping - gift;
  if (Number(order.total) < floor - 1) {
    return { ok: false, msg: 'El total de tu pedido no coincide con los precios actuales. Recarga la página e inténtalo de nuevo.', log: { total: order.total, minimo: floor, envioMinimo: minShipping } };
  }
  return { ok: true };
}

export default async function handler(req, res) {
  const secretKey = process.env.STRIPE_SECRET_KEY;
  if (!secretKey) {
    res.status(500).json({ error: 'STRIPE_SECRET_KEY no está configurada en Vercel todavía.' });
    return;
  }

  // ------------------------------------------------------------
  // GET: devuelve marca + últimos 4 dígitos de la tarjeta usada en un
  // PaymentIntent ya confirmado. El frontend la llama justo después de
  // que el pago se completa exitosamente.
  // ------------------------------------------------------------
  if (req.method === 'GET') {
    const paymentIntentId = req.query && req.query.paymentIntentId;
    if (!paymentIntentId) {
      res.status(400).json({ error: 'Falta paymentIntentId' });
      return;
    }
    try {
      const stripeRes = await fetch(
        `https://api.stripe.com/v1/payment_intents/${encodeURIComponent(paymentIntentId)}?expand[]=payment_method`,
        { headers: { 'Authorization': 'Bearer ' + secretKey } }
      );
      const data = await stripeRes.json();
      if (!stripeRes.ok) {
        res.status(400).json({ error: (data.error && data.error.message) || 'No se pudo consultar el pago.' });
        return;
      }
      const card = data.payment_method && data.payment_method.card;
      res.status(200).json({
        brand: (card && card.brand) || null,
        last4: (card && card.last4) || null,
      });
    } catch (err) {
      console.error('Error consultando detalles de tarjeta:', err);
      res.status(500).json({ error: 'Error del servidor al consultar la tarjeta.' });
    }
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Método no permitido' });
    return;
  }

  try {
    const fb = getFirebaseAdmin();
    const db = fb.firestore();
    const rl = await checkRateLimit(db, req, 'create-payment-intent', { windowMs: 10 * 60 * 1000, max: 10 });
    if (!rl.allowed) {
      res.setHeader('Retry-After', Math.ceil(rl.retryAfterMs / 1000));
      res.status(429).json({ error: 'Demasiados intentos de pago desde esta conexión. Espera unos minutos e intenta de nuevo.' });
      return;
    }
  } catch (e) {
    console.error('Rate limit create-payment-intent: error inesperado, se deja pasar —', e);
  }

  try {
    const { amount, currency = 'mxn', description = '', orderNum = '', digital = null, idToken = null, action = null, code = null } = req.body || {};

    // ------------------------------------------------------------
    // [TARJETAS DE REGALO · CANJE] Mueve el saldo de una tarjeta a la cuenta de quien la canjea. Se hace en el servidor,
    // dentro de una transacción: una tarjeta solo se puede canjear una vez y nadie puede inventar saldo.
    // (Se reutiliza esta función para no pasar el límite de 12 funciones de Vercel Hobby.)
    // ------------------------------------------------------------
    if (action === 'redeemGift') {
      const user = await verifiedUser(idToken);
      if (!user) { res.status(401).json({ error: 'Inicia sesión para canjear tu tarjeta de regalo.' }); return; }
      const gc = String(code || '').trim().toUpperCase();
      if (!/^ZY-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(gc)) { res.status(404).json({ error: 'Ese código no existe o ya expiró' }); return; }
      const db = getFirebaseAdmin().firestore();
      const cardRef = db.collection('giftcards').doc(gc);
      const balRef = db.collection('giftBalances').doc(user.uid);
      const out = await db.runTransaction(async (tx) => {
        const [c, b] = await Promise.all([tx.get(cardRef), tx.get(balRef)]);
        if (!c.exists) return { status: 404, error: 'Ese código no existe o ya expiró' };
        const card = c.data();
        const amt = Number(card.balance != null ? card.balance : card.amount) || 0;
        if (card.redeemedBy || amt <= 0) return { status: 409, error: 'Ese código ya fue canjeado' };
        const newBal = (b.exists ? Number(b.data().balance) || 0 : 0) + amt;
        tx.update(cardRef, { redeemedBy: user.uid, redeemedAt: Date.now(), balance: 0 });
        const bd = b.exists ? b.data() : {};
        const cards = Array.isArray(bd.cards) ? bd.cards.slice() : [];
        cards.push({ id: crypto.createHash('sha256').update(gc).digest('hex').slice(0, 12), last4: gc.slice(-4), original: Number(card.amount != null ? card.amount : amt) || amt, balance: amt, createdAt: Number(card.createdAt) || null, redeemedAt: Date.now() });
        tx.set(balRef, { balance: newBal, cards, updatedAt: Date.now() }, { merge: true });
        return { status: 200, amount: amt, balance: newBal };
      });
      if (out.error) { res.status(out.status).json({ error: out.error }); return; }
      res.status(200).json({ amount: out.amount, balance: out.balance });
      return;
    }
    const isGiftPay = action === 'payWithGift';   // pedido cubierto 100% con saldo de tarjeta de regalo (sin Stripe)
    if (isGiftPay && (!orderNum || String(orderNum).startsWith('DIG-'))) { res.status(400).json({ error: 'Número de pedido inválido.' }); return; }
    let metaUid = null;       // usuario verificado (se manda a Stripe como metadata para que el webhook sepa a quién activar/descontar)
    let giftUsedVerified = 0; // saldo de tarjeta de regalo ya verificado para este cobro
    const amountCents = isGiftPay ? 0 : Math.round(Number(amount));
    if (!isGiftPay && (!amountCents || amountCents < 1)) {
      res.status(400).json({ error: 'Monto inválido.' });
      return;
    }

    // [SEGURIDAD · MONTO] Un cobro de PEDIDO (ZY-…) solo se crea si el pedido ya está guardado
    // como pendiente, con pago por tarjeta, y el monto coincide con SU total (tolerancia $1).
    // Así nadie puede cambiar el monto en el navegador para pagar menos. Las compras digitales
    // (membresías/tarjetas de regalo, referencia DIG-…) no tienen pedido y siguen como antes.
    if (orderNum && !String(orderNum).startsWith('DIG-')) {
      if (!/^[A-Za-z0-9_-]{4,40}$/.test(String(orderNum))) {
        res.status(400).json({ error: 'Número de pedido inválido.' });
        return;
      }
      let order = null;
      try {
        const oSnap = await getFirebaseAdmin().firestore().collection('orders').doc(String(orderNum)).get();
        order = oSnap.exists ? oSnap.data() : null;
      } catch (e) {
        console.error('create-payment-intent: no se pudo verificar el pedido', e);
        res.status(503).json({ error: 'No pudimos verificar tu pedido en este momento. Intenta de nuevo en un minuto.' });
        return;
      }
      if (isGiftPay && order && order.paymentStatus === 'pagado' && order.paidWithGift) { res.status(200).json({ ok: true, already: true }); return; }
      const expectedCents = order ? Math.round(Number(order.total) * 100) : NaN;
      if (!order || order.paymentMethod !== 'stripe' || order.paymentStatus === 'pagado' || !isFinite(expectedCents) || Math.abs(amountCents - expectedCents) > 100) {
        console.error('create-payment-intent: cobro rechazado para', orderNum, { amountCents, expectedCents, existe: !!order });
        res.status(400).json({ error: 'El monto no coincide con tu pedido. Recarga la página e inténtalo de nuevo.' });
        return;
      }
      try {
        const privSnap = await getFirebaseAdmin().firestore().collection('orderPrivate').doc(String(orderNum)).get();
        const mxErr = mexicoError(order, privSnap.exists ? privSnap.data() : null);
        if (mxErr) {
          console.error('create-payment-intent: envío fuera de México rechazado en', orderNum, { state: order.state, zip: order.zip });
          res.status(400).json({ error: mxErr });
          return;
        }
      } catch (e) {
        console.error('create-payment-intent: no se pudo verificar la dirección', e);
        res.status(503).json({ error: 'No pudimos verificar tu dirección en este momento. Intenta de nuevo en un minuto.' });
        return;
      }
      let pricing;
      try {
        const user = await verifiedUser(idToken);
        if (user) metaUid = user.uid;
        let memberTier = null;
        if (user) {
          const mdoc = await getFirebaseAdmin().firestore().collection('memberships').doc(user.uid).get();
          const md = mdoc.exists ? mdoc.data() : null;
          if (md && md.tier && md.joinedAt && Date.now() - Number(md.joinedAt) < MEMBERSHIP_CYCLE_MS) memberTier = String(md.tier);
        }
        let giftBalance = 0;
        if ((Number(order.giftCardUsed) || 0) > 0 && user) {
          const b = await getFirebaseAdmin().firestore().collection('giftBalances').doc(user.uid).get();
          giftBalance = b.exists ? Number(b.data().balance) || 0 : 0;
        }
        pricing = await verifyOrderPricing(getFirebaseAdmin().firestore(), order, { giftBalance, memberTier });
        if (pricing.ok) giftUsedVerified = Number(order.giftCardUsed) || 0;
      } catch (e) {
        console.error('create-payment-intent: no se pudieron verificar los precios', e);
        res.status(503).json({ error: 'No pudimos verificar los precios en este momento. Intenta de nuevo en un minuto.' });
        return;
      }
      if (!pricing.ok) {
        console.error('create-payment-intent: PRECIOS NO VÁLIDOS en', orderNum, JSON.stringify(pricing.log || pricing.msg));
        res.status(400).json({ error: pricing.msg });
        return;
      }
      // [CUPÓN DE BIENVENIDA · UNA VEZ POR CORREO] Antes solo lo revisaba el navegador (y las reglas le impiden leer esa
      // lista), así que no se hacía cumplir. Ahora el servidor lo verifica; el webhook lo marca como usado al confirmarse el pago.
      if (order.coupon && String(order.coupon.code || '').toUpperCase() === 'BIENVENIDO10') {
        try {
          const email = String(order.email || '').trim().toLowerCase();
          if (!email) { res.status(400).json({ error: 'Para usar BIENVENIDO10 deja tu correo en el pedido.' }); return; }
          const dbw = getFirebaseAdmin().firestore();
          const [r, sub] = await Promise.all([
            dbw.collection('couponRedemptions').doc('BIENVENIDO10__' + encodeURIComponent(email)).get(),
            dbw.collection('newsletterSubscribers').doc(encodeURIComponent(email)).get(),
          ]);
          if (r.exists || (sub.exists && sub.data().welcomeCouponRedeemed)) {
            res.status(400).json({ error: 'El código BIENVENIDO10 ya fue usado con este correo. Quítalo e inténtalo de nuevo.' });
            return;
          }
        } catch (e) {
          console.error('create-payment-intent: no se pudo verificar BIENVENIDO10', e);
          res.status(503).json({ error: 'No pudimos verificar tu cupón en este momento. Intenta de nuevo en un minuto.' });
          return;
        }
      }
    } else if (orderNum) {
      // Una referencia DIG-… (compra digital) NUNCA puede tener un pedido con ese número; si no,
      // alguien podría crear un pedido "DIG-1" y saltarse la revisión de precios de arriba.
      if (!/^DIG-[A-Za-z0-9_-]{2,40}$/.test(String(orderNum))) {
        res.status(400).json({ error: 'Referencia de compra inválida.' });
        return;
      }
      try {
        const dbx = getFirebaseAdmin().firestore();
        const clash = await dbx.collection('orders').doc(String(orderNum)).get();
        if (clash.exists) { res.status(400).json({ error: 'Referencia de compra inválida.' }); return; }

        // [COMPRAS DIGITALES · VERIFICADAS] Antes una compra DIG-… no revisaba nada: el navegador decidía el monto y luego
        // se activaba la membresía por su cuenta. Ahora el servidor valida lo que se compra y quién compra, y lo deja
        // registrado; el webhook activa la membresía / emite la tarjeta SOLO cuando Stripe confirma el pago.
        const user = await verifiedUser(idToken);
        const dItems = digital && Array.isArray(digital.items) ? digital.items.slice(0, 10).map((it) => ({
          id: it && it.id ? String(it.id).slice(0, 60) : null,
          isMembership: !!(it && it.isMembership), tierName: it && it.tierName ? String(it.tierName).slice(0, 40) : null,
          isGiftCard: !!(it && it.isGiftCard), giftEmail: it && it.giftEmail ? String(it.giftEmail).trim().toLowerCase().slice(0, 200) : null,
          price: Number(it && it.price), qty: Number(it && it.qty),
        })) : null;
        if (!dItems || !dItems.length || dItems.some((it) => !(it.isMembership || it.isGiftCard))) {
          res.status(400).json({ error: 'No pudimos verificar tu compra. Recarga la página e inténtalo de nuevo.' }); return;
        }
        if (dItems.some((it) => it.isMembership) && !user) {
          res.status(401).json({ error: 'Inicia sesión para comprar tu membresía.' }); return;
        }
        if (dItems.some((it) => it.isGiftCard && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(it.giftEmail || ''))) {
          res.status(400).json({ error: 'El correo del destinatario de la tarjeta no es válido.' }); return;
        }
        const dTotal = dItems.reduce((a, it) => a + it.price * it.qty, 0);
        if (!isFinite(dTotal) || Math.abs(amountCents - Math.round(dTotal * 100)) > 100) {
          res.status(400).json({ error: 'El monto no coincide con tu compra. Recarga la página e inténtalo de nuevo.' }); return;
        }
        const dPricing = await verifyOrderPricing(dbx, { items: dItems, total: amountCents / 100, coupon: null, giftCardUsed: 0 }, { giftBalance: 0 });
        if (!dPricing.ok) {
          console.error('create-payment-intent: PRECIOS NO VÁLIDOS en compra digital', orderNum, JSON.stringify(dPricing.log || dPricing.msg));
          res.status(400).json({ error: dPricing.msg }); return;
        }
        const contact = (digital && digital.contact) || {};
        await dbx.collection('digitalPurchases').doc(String(orderNum)).create({
          uid: user ? user.uid : null, email: user ? user.email : null,
          buyerName: contact.name ? String(contact.name).slice(0, 120) : null,
          buyerEmail: contact.email ? String(contact.email).trim().toLowerCase().slice(0, 200) : (user ? user.email : null),
          items: dItems, amountCents, createdAt: Date.now(),
        });
        if (user) metaUid = user.uid;
      } catch (e) {
        console.error('create-payment-intent: no se pudo verificar la compra digital', e);
        res.status(503).json({ error: 'No pudimos verificar tu compra en este momento. Intenta de nuevo en un minuto.' });
        return;
      }
    }
    // ------------------------------------------------------------
    // [TARJETAS DE REGALO · PAGO 100% CON SALDO] Stripe no cobra $0, así que un pedido que el saldo cubre completo se cierra aquí.
    // Ya pasó TODAS las verificaciones de arriba (pedido guardado, total ~$0, precios, saldo verificado de la sesión). Primero se
    // descuenta el saldo (estricto, dentro de una transacción) y luego el pedido se cierra con la MISMA lógica que el webhook de
    // Stripe (processPaidOrder): pagado, confirmación, ventas de vendedor, etc. Si no se puede completar, se devuelve el saldo.
    // ------------------------------------------------------------
    if (isGiftPay) {
      if (!metaUid || !(giftUsedVerified > 0)) { res.status(400).json({ error: 'Este pedido no está cubierto por tu saldo de tarjeta de regalo.' }); return; }
      const dbg = getFirebaseAdmin().firestore();
      const payId = 'gift_' + String(orderNum);
      let hook;
      try { hook = await import('./stripe-webhook.js'); }
      catch (e) { console.error('create-payment-intent: no se pudo cargar el cierre de pedidos', e); res.status(500).json({ error: 'No pudimos completar el pago con tu saldo. Intenta de nuevo en un minuto.' }); return; }
      let debit;
      try { debit = await hook.debitGiftBalance(dbg, payId, metaUid, giftUsedVerified, { strict: true }); }
      catch (e) { console.error('create-payment-intent: no se pudo descontar el saldo', e); res.status(503).json({ error: 'No pudimos usar tu saldo en este momento. Intenta de nuevo en un minuto.' }); return; }
      if (!debit || !debit.ok) { res.status(409).json({ error: 'Tu saldo de tarjeta de regalo ya no alcanza para este pedido. Recarga la página e inténtalo de nuevo.' }); return; }
      try {
        const r = await hook.processPaidOrder(dbg, String(orderNum), { id: payId, amount: 0, amount_received: 0, gift: true, metadata: { orderNum: String(orderNum), uid: metaUid, giftUid: metaUid, giftUsed: String(giftUsedVerified) } });
        if (r && r.warning) throw new Error(r.warning);
      } catch (e) {
        console.error('create-payment-intent: falló el cierre del pedido pagado con saldo', orderNum, e);
        let paid = false;
        try { const o2 = await dbg.collection('orders').doc(String(orderNum)).get(); paid = !!(o2.exists && o2.data().paymentStatus === 'pagado'); } catch (e3) {}
        if (paid) { res.status(200).json({ ok: true, warning: 'incompleto' }); return; }   // ya quedó pagado: el saldo se queda descontado; lo faltante se revisa en los registros
        try { await hook.undoGiftDebit(dbg, payId, metaUid); } catch (e2) { console.error('create-payment-intent: NO se pudo devolver el saldo de', orderNum, e2); }
        res.status(500).json({ error: 'No pudimos completar tu pedido con el saldo. No se descontó nada; inténtalo de nuevo.' });
        return;
      }
      res.status(200).json({ ok: true });
      return;
    }
    const params = new URLSearchParams();
    params.append('amount', String(amountCents)); // Stripe espera centavos
    params.append('currency', currency);
    if (description) params.append('description', description);
    if (orderNum) params.append('metadata[orderNum]', orderNum);
    if (metaUid) params.append('metadata[uid]', metaUid);
    if (giftUsedVerified > 0 && metaUid) { params.append('metadata[giftUid]', metaUid); params.append('metadata[giftUsed]', String(giftUsedVerified)); }
    params.append('automatic_payment_methods[enabled]', 'true');
    const stripeRes = await fetch('https://api.stripe.com/v1/payment_intents', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + secretKey,
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: params.toString()
    });
    const data = await stripeRes.json();
    if (!stripeRes.ok) {
      res.status(400).json({ error: (data.error && data.error.message) || 'No se pudo crear el pago.' });
      return;
    }
    res.status(200).json({ clientSecret: data.client_secret });
  } catch (err) {
    console.error('Error creando PaymentIntent:', err);
    res.status(500).json({ error: 'Error del servidor al procesar el pago.' });
  }
}
