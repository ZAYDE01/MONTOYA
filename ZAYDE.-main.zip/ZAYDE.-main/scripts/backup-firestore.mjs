// Exporta las colecciones de ZAYDE a backup/<coleccion>.json. Lo usa .github/workflows/backup-firestore.yml
import admin from 'firebase-admin';
import { mkdirSync, writeFileSync } from 'node:fs';

const COLS = ['admin_products','admin_overrides','admin_meta','inventory','orders','orderPrivate','memberships','giftBalances','giftcards','digitalPurchases','digitalFulfillments','giftDebits','sellers','sellerHelpers','sellerSales','sellerSalesPrivate','sellerPayouts','sellerDocs','sellerSubmissions','sellerTickets','sellerChangeRequests','stockLog','priceHistory','reviews','newsletterSubscribers','dropSubscribers','abandonedCarts','returns'];

let raw = process.env.FIREBASE_SERVICE_ACCOUNT || '';
if(!raw){ console.error('Falta el secreto FIREBASE_SERVICE_ACCOUNT'); process.exit(1); }
if(!raw.trim().startsWith('{')) raw = Buffer.from(raw, 'base64').toString('utf8');   // acepta JSON o JSON en base64
admin.initializeApp({ credential: admin.credential.cert(JSON.parse(raw)) });
const db = admin.firestore();

// Convierte Timestamps y referencias a valores simples para poder guardarlos como JSON
const clean = v => {
  if(v == null || typeof v !== 'object') return v;
  if(typeof v.toDate === 'function') return v.toDate().toISOString();
  if(Array.isArray(v)) return v.map(clean);
  if(v.path && v.firestore) return v.path;
  return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, clean(x)]));
};

mkdirSync('backup', { recursive: true });
let failed = 0;
for(const col of COLS){
  try{
    const out = []; let last = null;
    for(;;){
      let q = db.collection(col).orderBy(admin.firestore.FieldPath.documentId()).limit(500);
      if(last) q = q.startAfter(last);
      const snap = await q.get();
      if(snap.empty) break;
      snap.docs.forEach(d => out.push({ id: d.id, data: clean(d.data()) }));
      last = snap.docs[snap.docs.length - 1];
      if(snap.size < 500) break;
    }
    writeFileSync('backup/' + col + '.json', JSON.stringify(out));
    console.log(col + ': ' + out.length + ' documentos');
  }catch(e){
    failed++; console.error(col + ': ERROR ' + (e && e.message || e));
  }
}
writeFileSync('backup/_info.json', JSON.stringify({ at: new Date().toISOString(), colecciones: COLS, errores: failed }));
process.exit(failed ? 1 : 0);   // si algo falla, GitHub marca la ejecución en rojo y te avisa por correo
